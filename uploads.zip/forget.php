<?php
// forgot-password.php
require_once 'config.php';

// Handle branch data from database
$branches = getAllBranches();
$selectedBranch = null;

// Handle branch selection
if (isset($_GET['branch_id']) && is_numeric($_GET['branch_id'])) {
    $selectedBranch = getBranchById($_GET['branch_id']);
}

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] == 'get_branch_details') {
        $branchId = $_POST['branch_id'];
        $branch = getBranchById($branchId);
        
        echo json_encode([
            'success' => true,
            'branch' => $branch
        ]);
        exit;
    }
    
    if ($_POST['action'] == 'search_branches' && isset($_POST['query'])) {
        $results = searchBranches($_POST['query']);
        
        echo json_encode([
            'success' => true,
            'branches' => $results
        ]);
        exit;
    }
    
    if ($_POST['action'] == 'download_form') {
        // Log the download request
        if (isset($_SESSION['user_id'])) {
            logAction('password_reset_form_download', 'User downloaded password reset form');
        } else {
            logAction('password_reset_form_download', 'Guest downloaded password reset form');
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Form download logged successfully'
        ]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Your Password? | Losers Bank</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS Variables */
        :root {
            --color-deep-navy: #0a1d37;
            --color-gold: #d4af37;
            --color-light-gold: #f4e4a9;
            --color-white: #ffffff;
            --color-light-gray: #f5f5f5;
            --color-dark-blue: #051428;
            --font-heading: 'Montserrat', sans-serif;
            --font-body: 'Open Sans', sans-serif;
        }

        /* Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--font-body);
            background: linear-gradient(135deg, var(--color-deep-navy) 0%, var(--color-dark-blue) 100%);
            color: var(--color-white);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 1.5rem;
        }

        /* Header Styles */
        .page-header {
            text-align: center;
            padding: 4rem 0 3rem;
            position: relative;
            overflow: hidden;
        }

        .header-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 80%, rgba(212, 175, 55, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, rgba(212, 175, 55, 0.05) 0%, transparent 50%);
            z-index: -1;
        }

        .bank-logo {
            height: 70px;
            margin-bottom: 1.5rem;
            filter: brightness(0) invert(1);
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .header-title {
            font-family: var(--font-heading);
            font-size: 3.5rem;
            margin-bottom: 0.5rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--color-white), var(--color-light-gold));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 30px rgba(212, 175, 55, 0.3);
        }

        .header-subtitle {
            font-size: 1.3rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Main Content Styles */
        .page-main {
            padding-bottom: 4rem;
        }

        .info-section .lead-text {
            font-size: 1.2rem;
            margin-bottom: 3rem;
            text-align: center;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 1rem;
            border-left: 4px solid var(--color-gold);
        }

        /* Process Steps Styles */
        .process-flow {
            margin-bottom: 4rem;
            position: relative;
        }

        .process-flow::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--color-gold), transparent);
            z-index: -1;
        }

        .process-flow h2 {
            font-family: var(--font-heading);
            text-align: center;
            margin-bottom: 3rem;
            font-size: 2.2rem;
            position: relative;
            display: inline-block;
            left: 50%;
            transform: translateX(-50%);
        }

        .process-flow h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 25%;
            width: 50%;
            height: 3px;
            background: var(--color-gold);
            border-radius: 2px;
        }

        .steps-container {
            display: flex;
            flex-direction: column;
            gap: 2.5rem;
        }

        .step {
            display: flex;
            align-items: center;
            opacity: 0;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 1rem;
            padding: 2rem;
            position: relative;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .step:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.08);
        }

        .step:nth-child(odd) {
            flex-direction: row;
            margin-right: 10%;
        }

        .step:nth-child(even) {
            flex-direction: row-reverse;
            margin-left: 10%;
            text-align: right;
        }

        .step-icon {
            font-size: 2.5rem;
            margin: 0 1.5rem;
            flex-shrink: 0;
            width: 80px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(212, 175, 55, 0.1);
            border-radius: 50%;
            border: 2px solid var(--color-gold);
        }

        .step-content {
            flex: 1;
        }

        .step-content h3 {
            font-family: var(--font-heading);
            margin-bottom: 0.8rem;
            color: var(--color-gold);
            font-size: 1.5rem;
        }

        .documents-list {
            margin: 0;
            padding-left: 1.5rem;
        }

        .documents-list li {
            margin-bottom: 0.5rem;
            position: relative;
        }

        /* Action Cards Styles */
        .action-cards {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 4rem;
        }

        @media (max-width: 768px) {
            .action-cards {
                grid-template-columns: 1fr;
            }
            
            .step:nth-child(odd),
            .step:nth-child(even) {
                flex-direction: column;
                margin: 0;
                text-align: left;
            }
            
            .process-flow::before {
                display: none;
            }
        }

        .card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1.5rem;
            padding: 2rem;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(to right, var(--color-gold), var(--color-light-gold));
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
        }

        .card h3 {
            font-family: var(--font-heading);
            margin-bottom: 1rem;
            color: var(--color-gold);
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .contact-list {
            list-style-type: none;
            margin-bottom: 1.5rem;
        }

        .contact-list li {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .disclaimer {
            font-style: italic;
            font-size: 0.9rem;
            margin-top: 1.5rem;
            padding: 1rem;
            background: rgba(212, 175, 55, 0.1);
            border-radius: 0.5rem;
            border-left: 3px solid var(--color-gold);
        }

        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.9rem 2rem;
            border-radius: 2rem;
            text-decoration: none;
            font-weight: 600;
            text-align: center;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            margin-top: 0.5rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--color-gold), #e6c965);
            color: var(--color-deep-navy);
            box-shadow: 0 4px 15px rgba(212, 175, 55, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.6);
        }

        .btn-secondary {
            background: transparent;
            color: var(--color-white);
            border: 2px solid var(--color-gold);
        }

        .btn-secondary:hover {
            background: var(--color-gold);
            color: var(--color-deep-navy);
        }

        .text-link {
            color: var(--color-gold);
            text-decoration: none;
            position: relative;
        }

        .text-link::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--color-gold);
            transition: width 0.3s ease;
        }

        .text-link:hover::after {
            width: 100%;
        }

        /* Branch Locator Styles */
        .branch-locator {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 1.5rem;
            padding: 2rem;
            margin-bottom: 4rem;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .locator-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .locator-header h2 {
            font-family: var(--font-heading);
            color: var(--color-gold);
            font-size: 1.8rem;
        }

        .search-box {
            display: flex;
            gap: 0.5rem;
            flex: 1;
            min-width: 300px;
        }

        .search-box input {
            flex: 1;
            padding: 0.8rem 1rem;
            border-radius: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.1);
            color: var(--color-white);
            font-family: var(--font-body);
        }

        .search-box input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .search-btn {
            padding: 0.8rem 1.5rem;
            border-radius: 2rem;
            background: var(--color-gold);
            color: var(--color-deep-navy);
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            background: var(--color-light-gold);
            transform: translateY(-2px);
        }

        .branches-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        @media (max-width: 900px) {
            .branches-container {
                grid-template-columns: 1fr;
            }
        }

        .branches-list {
            max-height: 500px;
            overflow-y: auto;
            padding-right: 1rem;
        }

        .branch-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }

        .branch-item:hover, .branch-item.active {
            background: rgba(255, 255, 255, 0.08);
            border-color: var(--color-gold);
            transform: translateY(-3px);
        }

        .branch-item h3 {
            color: var(--color-gold);
            margin-bottom: 0.5rem;
            font-family: var(--font-heading);
        }

        .branch-details {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .branch-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .branch-features {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .feature-tag {
            font-size: 0.7rem;
            padding: 0.2rem 0.5rem;
            background: rgba(212, 175, 55, 0.2);
            border-radius: 1rem;
            border: 1px solid rgba(212, 175, 55, 0.3);
        }

        .branch-map {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 1rem;
            padding: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 400px;
            position: relative;
            overflow: hidden;
        }

        .map-placeholder {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
        }

        .map-placeholder i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--color-gold);
        }

        /* Security Tips Section */
        .security-tips-section {
            margin-bottom: 4rem;
        }

        .security-tips-section h2 {
            font-family: var(--font-heading);
            text-align: center;
            margin-bottom: 3rem;
            font-size: 2.2rem;
            position: relative;
        }

        .security-tips-section h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: var(--color-gold);
            border-radius: 2px;
        }

        .tips-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
        }

        .tip-item {
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.05);
            padding: 1.5rem;
            border-radius: 1rem;
            opacity: 0;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .tip-item:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .tip-item .tip-icon {
            font-size: 2rem;
            margin-right: 1.5rem;
            flex-shrink: 0;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(212, 175, 55, 0.1);
            border-radius: 50%;
        }

        .tip-item p {
            margin: 0;
            font-size: 1.1rem;
        }

        /* Footer Styles */
        .page-footer {
            text-align: center;
            padding: 3rem 0;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(5, 20, 40, 0.5);
        }

        .page-footer a {
            color: var(--color-gold);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .page-footer a:hover {
            text-decoration: underline;
        }

        .floating-particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: var(--color-gold);
            border-radius: 50%;
            opacity: 0.3;
        }

        /* Loading States */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: var(--color-gold);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Success Message */
        .success-message {
            background: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.5);
            color: #d4edda;
            padding: 1rem;
            border-radius: 0.5rem;
            margin: 1rem 0;
            display: none;
        }
    </style>
</head>
<body>
    <div class="floating-particles" id="particles-container"></div>

    <!-- 1️⃣ Header Section -->
    <header class="page-header">
        <div class="header-bg"></div>
        <div class="container">
            <div class="bank-logo">
                <i class="fas fa-university fa-3x"></i>
            </div>
            <h1 class="header-title">Forgot Your Password?</h1>
            <p class="header-subtitle">
                <i class="fas fa-shield-alt"></i> For your protection, Losers Bank does not reset passwords online.
            </p>
        </div>
    </header>

    <main class="page-main">
        <div class="container">

            <!-- 2️⃣ Main Information Section -->
            <section class="info-section">
                <p class="lead-text">
                    To ensure the highest level of account safety, all password reset requests must be verified <strong>in person</strong> at your nearest Losers Bank branch. This helps us confirm your identity directly and prevent unauthorized access to your funds.
                </p>

                <div class="process-flow">
                    <h2>In-Branch Password Reset Process</h2>
                    <div class="steps-container">
                        <!-- Step 1 -->
                        <div class="step">
                            <div class="step-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="step-content">
                                <h3>Visit your nearest Losers Bank branch</h3>
                                <p>Use our <a href="#branch-locator" class="text-link">Branch Locator</a> to find one near you.</p>
                            </div>
                        </div>
                        <!-- Step 2 -->
                        <div class="step">
                            <div class="step-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="step-content">
                                <h3>Bring the following documents</h3>
                                <ul class="documents-list">
                                    <li><i class="fas fa-id-card"></i> Valid photo ID (NID / Passport / Driving License)</li>
                                    <li><i class="fas fa-file-invoice"></i> Account number or printed statement</li>
                                    <li><i class="fas fa-edit"></i> Completed <strong>Password Reset Request Form</strong> (download below)</li>
                                    <li><i class="fas fa-receipt"></i> <em>Optional: proof of recent transaction (last deposit/withdrawal)</em></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Step 3 -->
                        <div class="step">
                            <div class="step-icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="step-content">
                                <h3>Meet with a bank officer</h3>
                                <p>Our officer will verify your identity and reset your password securely.</p>
                            </div>
                        </div>
                        <!-- Step 4 -->
                        <div class="step">
                            <div class="step-icon">
                                <i class="fas fa-lock"></i>
                            </div>
                            <div class="step-content">
                                <h3>Confirmation</h3>
                                <p>You'll receive your new login credentials in a sealed confidential envelope or as per bank policy.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Download & Support -->
                <div class="action-cards">
                    <div class="card download-card">
                        <h3><i class="fas fa-download"></i> Download Form</h3>
                        <p>Have your form ready before you visit.</p>
                        <div class="success-message" id="download-success">
                            <i class="fas fa-check-circle"></i> Form download logged successfully!
                        </div>
                        <button class="btn btn-primary" onclick="downloadForm()" id="download-btn">
                            <i class="fas fa-file-pdf"></i> Download Password Reset Form (PDF)
                        </button>
                    </div>

                    <div class="card support-card">
                        <h3><i class="fas fa-headset"></i> Need Help?</h3>
                        <ul class="contact-list">
                            <li><i class="fas fa-phone"></i> <strong>Helpline:</strong> +8801XXXXXXX</li>
                            <li><i class="fas fa-envelope"></i> <strong>Email:</strong> <a href="mailto:support@losersbank.com" class="text-link">support@losersbank.com</a></li>
                            <li><i class="fas fa-clock"></i> <strong>Service Hours:</strong> Sunday – Thursday | 9:00 AM – 5:00 PM</li>
                        </ul>
                        <p class="disclaimer">
                            <i class="fas fa-exclamation-triangle"></i> Please do not share your password or OTP with anyone, even if they claim to be from Losers Bank.
                        </p>
                    </div>
                </div>
            </section>

            <!-- Branch Locator Section -->
            <section class="branch-locator" id="branch-locator">
                <div class="locator-header">
                    <h2><i class="fas fa-map-marked-alt"></i> Find Your Nearest Branch</h2>
                    <div class="search-box">
                        <input type="text" id="branch-search" placeholder="Enter your city or area...">
                        <button class="search-btn" onclick="searchBranches()"><i class="fas fa-search"></i> Search</button>
                    </div>
                </div>
                
                <div class="branches-container">
                    <div class="branches-list" id="branches-list">
                        <!-- Branches will be populated by JavaScript from database -->
                    </div>
                    <div class="branch-map" id="branch-map-container">
                        <div class="map-placeholder" id="map-placeholder">
                            <i class="fas fa-map"></i>
                            <p>Select a branch to view its location on the map</p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- 3️⃣ Security Tips Section -->
            <section class="security-tips-section">
                <h2>Security Awareness</h2>
                <div class="tips-container">
                    <div class="tip-item">
                        <div class="tip-icon"><i class="fas fa-link"></i></div>
                        <p>Never click suspicious links or open unknown attachments.</p>
                    </div>
                    <div class="tip-item">
                        <div class="tip-icon"><i class="fas fa-phone-slash"></i></div>
                        <p>Losers Bank never calls to ask for your password.</p>
                    </div>
                    <div class="tip-item">
                        <div class="tip-icon"><i class="fas fa-sync-alt"></i></div>
                        <p>Change your password regularly at the branch.</p>
                    </div>
                    <div class="tip-item">
                        <div class="tip-icon"><i class="fas fa-sign-out-alt"></i></div>
                        <p>Always log out after using your account.</p>
                    </div>
                </div>
            </section>

        </div> <!-- /.container -->
    </main>

    <!-- 4️⃣ Footer -->
    <footer class="page-footer">
        <div class="container">
            <p>© <span id="current-year">2024</span> Losers Bank | <a href="#">Privacy Policy</a> | <a href="#">Security Center</a> | <a href="#">Contact Us</a></p>
        </div>
    </footer>

    <script>
        // Create floating particles
        function createParticles() {
            const container = document.getElementById('particles-container');
            const particleCount = 30;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random position
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                
                // Random size
                const size = Math.random() * 3 + 1;
                
                // Random animation
                const duration = Math.random() * 20 + 10;
                const delay = Math.random() * 5;
                
                particle.style.left = `${posX}%`;
                particle.style.top = `${posY}%`;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.animation = `float ${duration}s ease-in-out ${delay}s infinite`;
                
                container.appendChild(particle);
            }
        }

        // Display branches from database
        function displayBranches(branchList = []) {
            const branchesList = document.getElementById('branches-list');
            
            if (branchList.length === 0) {
                branchesList.innerHTML = `
                    <div class="branch-item">
                        <h3>No branches found</h3>
                        <p>Please try a different search term or check back later.</p>
                    </div>
                `;
                return;
            }
            
            branchesList.innerHTML = '';
            
            branchList.forEach(branch => {
                const branchItem = document.createElement('div');
                branchItem.className = 'branch-item';
                branchItem.setAttribute('data-branch-id', branch.id);
                
                // Create features list
                const features = [];
                if (branch.is_atm_available) features.push('ATM');
                if (branch.has_parking) features.push('Parking');
                if (branch.is_wheelchair_accessible) features.push('Wheelchair Access');
                if (branch.has_drive_thru) features.push('Drive-thru');
                
                const featuresHtml = features.length > 0 ? `
                    <div class="branch-features">
                        ${features.map(feature => `<span class="feature-tag">${feature}</span>`).join('')}
                    </div>
                ` : '';
                
                branchItem.innerHTML = `
                    <h3>${branch.name}</h3>
                    <div class="branch-details">
                        <div class="branch-detail">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${branch.address}</span>
                        </div>
                        <div class="branch-detail">
                            <i class="fas fa-phone"></i>
                            <span>${branch.phone}</span>
                        </div>
                        <div class="branch-detail">
                            <i class="fas fa-envelope"></i>
                            <span>${branch.email}</span>
                        </div>
                        <div class="branch-detail">
                            <i class="fas fa-user-tie"></i>
                            <span>Manager: ${branch.manager_name}</span>
                        </div>
                        <div class="branch-detail">
                            <i class="fas fa-clock"></i>
                            <span>${branch.opening_hours.replace(/,/g, '<br>')}</span>
                        </div>
                    </div>
                    ${featuresHtml}
                `;
                
                branchItem.addEventListener('click', () => {
                    // Remove active class from all branches
                    document.querySelectorAll('.branch-item').forEach(item => {
                        item.classList.remove('active');
                    });
                    
                    // Add active class to clicked branch
                    branchItem.classList.add('active');
                    
                    // Load branch details and show on map
                    loadBranchDetails(branch.id);
                });
                
                branchesList.appendChild(branchItem);
            });
            
            // Activate the first branch by default
            if (branchesList.firstChild) {
                branchesList.firstChild.classList.add('active');
                const firstBranchId = branchesList.firstChild.getAttribute('data-branch-id');
                loadBranchDetails(firstBranchId);
            }
        }

        // Load branch details via AJAX
        function loadBranchDetails(branchId) {
            const mapContainer = document.getElementById('branch-map-container');
            const placeholder = document.getElementById('map-placeholder');
            
            // Show loading state
            placeholder.innerHTML = '<div class="loading"></div><p>Loading branch details...</p>';
            
            const formData = new FormData();
            formData.append('action', 'get_branch_details');
            formData.append('branch_id', branchId);
            
            fetch('forgot-password.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.branch) {
                    showBranchOnMap(data.branch);
                } else {
                    placeholder.innerHTML = '<i class="fas fa-exclamation-triangle"></i><p>Error loading branch details</p>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                placeholder.innerHTML = '<i class="fas fa-exclamation-triangle"></i><p>Error loading branch details</p>';
            });
        }

        // Show branch on map
        function showBranchOnMap(branch) {
            const mapContainer = document.getElementById('branch-map-container');
            
            if (branch.latitude && branch.longitude) {
                // In a real implementation, you would integrate with Google Maps API
                // For now, we'll show a static map or coordinates
                mapContainer.innerHTML = `
                    <div class="map-placeholder">
                        <i class="fas fa-map-marker-alt"></i>
                        <h4>${branch.name}</h4>
                        <p>📍 ${branch.address}</p>
                        <p>📞 ${branch.phone}</p>
                        <p>🕒 ${branch.opening_hours.replace(/,/g, '<br>')}</p>
                        <p><small>Coordinates: ${branch.latitude}, ${branch.longitude}</small></p>
                        <a href="https://maps.google.com/?q=${encodeURIComponent(branch.address)}" 
                           target="_blank" class="btn btn-secondary" style="margin-top: 1rem;">
                            <i class="fas fa-directions"></i> Get Directions
                        </a>
                    </div>
                `;
            } else {
                mapContainer.innerHTML = `
                    <div class="map-placeholder">
                        <i class="fas fa-map-marker-alt"></i>
                        <h4>${branch.name}</h4>
                        <p>📍 ${branch.address}</p>
                        <p>📞 ${branch.phone}</p>
                        <p>🕒 ${branch.opening_hours.replace(/,/g, '<br>')}</p>
                        <a href="https://maps.google.com/?q=${encodeURIComponent(branch.address)}" 
                           target="_blank" class="btn btn-secondary" style="margin-top: 1rem;">
                            <i class="fas fa-directions"></i> Get Directions
                        </a>
                    </div>
                `;
            }
        }

        // Search branches by city or area
        function searchBranches() {
            const searchTerm = document.getElementById('branch-search').value.toLowerCase();
            const branchesList = document.getElementById('branches-list');
            
            // Show loading state
            branchesList.innerHTML = '<div class="branch-item"><div class="loading"></div><p>Searching branches...</p></div>';
            
            if (searchTerm.trim() === '') {
                // If search is empty, reload all branches from PHP
                location.reload();
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'search_branches');
            formData.append('query', searchTerm);
            
            fetch('forgot-password.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayBranches(data.branches);
                } else {
                    branchesList.innerHTML = '<div class="branch-item"><i class="fas fa-exclamation-triangle"></i><p>Error searching branches</p></div>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                branchesList.innerHTML = '<div class="branch-item"><i class="fas fa-exclamation-triangle"></i><p>Error searching branches</p></div>';
            });
        }

        // Download form with database logging
        function downloadForm() {
            const downloadBtn = document.getElementById('download-btn');
            const successMessage = document.getElementById('download-success');
            const originalText = downloadBtn.innerHTML;
            
            // Show loading state
            downloadBtn.innerHTML = '<div class="loading"></div> Downloading...';
            downloadBtn.disabled = true;
            
            // Log the download in database
            const formData = new FormData();
            formData.append('action', 'download_form');
            
            fetch('forgot-password.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Create a simple PDF download simulation
                    const link = document.createElement('a');
                    link.href = '#'; // In real implementation, link to actual PDF
                    link.download = 'Losers-Bank-Password-Reset-Form.pdf';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    // Show success message
                    successMessage.style.display = 'block';
                    
                    // Reset button after 3 seconds
                    setTimeout(() => {
                        downloadBtn.innerHTML = originalText;
                        downloadBtn.disabled = false;
                    }, 3000);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                downloadBtn.innerHTML = originalText;
                downloadBtn.disabled = false;
                alert('Error downloading form. Please try again.');
            });
        }

        // GSAP Animations
        document.addEventListener('DOMContentLoaded', function() {
            // Register ScrollTrigger plugin
            gsap.registerPlugin(ScrollTrigger);

            // Create particles
            createParticles();

            // Display branches from PHP
            displayBranches(<?php echo json_encode($branches); ?>);

            // 1. Header fade-in
            gsap.from('.page-header', {
                opacity: 0,
                y: 50,
                duration: 1,
                ease: "power2.out"
            });

            // 2. Step-by-step list staggered animation
            gsap.from('.step', {
                scrollTrigger: {
                    trigger: '.steps-container',
                    start: 'top 80%',
                    end: 'bottom 20%',
                    toggleActions: 'play none none none'
                },
                opacity: 0,
                y: 30,
                duration: 0.8,
                stagger: 0.3,
                ease: "power2.out"
            });

            // 3. Security tips staggered animation on scroll
            gsap.from('.tip-item', {
                scrollTrigger: {
                    trigger: '.tips-container',
                    start: 'top 80%',
                    end: 'bottom 20%',
                    toggleActions: 'play none none none'
                },
                opacity: 0,
                y: 20,
                duration: 0.6,
                stagger: 0.2,
                ease: "power2.out"
            });

            // 4. Card animations
            gsap.from('.card', {
                scrollTrigger: {
                    trigger: '.action-cards',
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                },
                opacity: 0,
                y: 30,
                duration: 0.8,
                stagger: 0.2,
                ease: "power2.out"
            });

            // 5. Branch locator animation
            gsap.from('.branch-locator', {
                scrollTrigger: {
                    trigger: '.branch-locator',
                    start: 'top 85%',
                    toggleActions: 'play none none none'
                },
                opacity: 0,
                y: 40,
                duration: 1,
                ease: "power2.out"
            });

            // 6. Button hover animations
            const buttons = document.querySelectorAll('.btn');
            buttons.forEach(button => {
                button.addEventListener('mouseenter', function() {
                    gsap.to(this, { scale: 1.05, duration: 0.2 });
                });
                button.addEventListener('mouseleave', function() {
                    gsap.to(this, { scale: 1, duration: 0.2 });
                });
            });

            // Update current year in footer
            document.getElementById('current-year').textContent = new Date().getFullYear();
        });

        // Handle Enter key in search
        document.getElementById('branch-search').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchBranches();
            }
        });
    </script>
</body>
</html>