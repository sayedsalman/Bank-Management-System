<?php
// config.php - Optimized for Online Hosting
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent re-declaration or double inclusion
if (!defined('CONFIG_LOADED')) {
    define('CONFIG_LOADED', true);

    $isProduction = ($_SERVER['SERVER_NAME'] ?? '') !== 'localhost';
    
    if ($isProduction) {
        $host = 'localhost'; // Most hosts use localhost
        $dbname = 'rfnhscco_bank'; // Replace with your actual DB name
        $username = 'rfnhscco_bank'; // Replace with your actual DB username
        $password = 'c$wH0K8,+l]CCi];'; // Replace with your actual DB password
        
        // Error reporting for production
        error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
        ini_set('display_errors', 0);
        ini_set('log_errors', 1);
    } else {
        // Development environment (local)
        $host = 'localhost';
        $dbname = 'losers_bank';
        $username = 'root';
        $password = '';
        
        // Error reporting for development
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    }

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]);
    } catch (PDOException $e) {
        // Secure error message for production
        if ($isProduction) {
            error_log("Database connection failed: " . $e->getMessage());
            die("System temporarily unavailable. Please try again later.");
        } else {
            die("Connection failed: " . $e->getMessage());
        }
    }

    // ✅ Security headers
    if (!headers_sent()) {
        header("X-Frame-Options: DENY");
        header("X-Content-Type-Options: nosniff");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
        
        // Only set strict transport security in production with SSL
        if ($isProduction && (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) {
            header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
        }
    }

    // ✅ Helper functions
    // ✅ Helper functions
if (!function_exists('isLoggedIn')) {
    function isLoggedIn(): bool {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
}

if (!function_exists('getUserRole')) {
    function getUserRole(): ?string {
        return $_SESSION['role'] ?? null;
    }
}

if (!function_exists('isAdmin')) {
    function isAdmin(): bool {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}

if (!function_exists('redirectIfNotLoggedIn')) {
    function redirectIfNotLoggedIn(): void {
        if (!isLoggedIn()) {
            header('Location: login.php');
            exit();
        }
    }
}

if (!function_exists('logAction')) {
    function logAction($action, $description): void {
        global $pdo;
        try {
            $stmt = $pdo->prepare("
                INSERT INTO s_system_logs (user_id, action, description, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'] ?? null,
                $action,
                $description,
                $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);
        } catch (PDOException $e) {
            error_log("Failed to log action: " . $e->getMessage());
        }
    }
}

    // ✅ Branch-related functions
    if (!function_exists('getAllBranches')) {
        function getAllBranches() {
            global $pdo;
            try {
                $stmt = $pdo->prepare("
                    SELECT b.*, 
                           COALESCE((SELECT AVG(rating) FROM branch_reviews WHERE branch_id = b.id AND is_approved = 1), 0) as avg_rating,
                           COALESCE((SELECT COUNT(*) FROM branch_reviews WHERE branch_id = b.id AND is_approved = 1), 0) as review_count
                    FROM branches b 
                    ORDER BY b.name
                ");
                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log("Error getting branches: " . $e->getMessage());
                return [];
            }
        }
    }

    if (!function_exists('getBranchById')) {
        function getBranchById($id) {
            global $pdo;
            try {
                $stmt = $pdo->prepare("
                    SELECT b.*, 
                           COALESCE((SELECT AVG(rating) FROM branch_reviews WHERE branch_id = b.id AND is_approved = 1), 0) as avg_rating,
                           COALESCE((SELECT COUNT(*) FROM branch_reviews WHERE branch_id = b.id AND is_approved = 1), 0) as review_count
                    FROM branches b 
                    WHERE b.id = ?
                ");
                $stmt->execute([$id]);
                return $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log("Error getting branch by ID: " . $e->getMessage());
                return null;
            }
        }
    }

    if (!function_exists('getBranchReviews')) {
        function getBranchReviews($branchId, $limit = 5) {
            global $pdo;
            try {
                $stmt = $pdo->prepare("
                    SELECT br.*, u.first_name, u.last_name 
                    FROM branch_reviews br 
                    JOIN users u ON br.user_id = u.id 
                    WHERE br.branch_id = ? AND br.is_approved = 1 
                    ORDER BY br.created_at DESC 
                    LIMIT ?
                ");
                $stmt->execute([$branchId, $limit]);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log("Error getting branch reviews: " . $e->getMessage());
                return [];
            }
        }
    }

    if (!function_exists('logBranchVisit')) {
        function logBranchVisit($branchId, $purpose = 'inquiry') {
            global $pdo;
            if (isLoggedIn()) {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO branch_visits (branch_id, user_id, visit_date, visit_time, purpose)
                        VALUES (?, ?, CURDATE(), CURTIME(), ?)
                    ");
                    $stmt->execute([$branchId, $_SESSION['user_id'], $purpose]);
                    return true;
                } catch (PDOException $e) {
                    error_log("Error logging branch visit: " . $e->getMessage());
                    return false;
                }
            }
            return false;
        }
    }

    if (!function_exists('searchBranches')) {
        function searchBranches($query) {
            global $pdo;
            try {
                $searchTerm = '%' . $query . '%';
                $stmt = $pdo->prepare("
                    SELECT b.*, 
                           COALESCE((SELECT AVG(rating) FROM branch_reviews WHERE branch_id = b.id AND is_approved = 1), 0) as avg_rating
                    FROM branches b 
                    WHERE b.name LIKE ? OR b.address LIKE ? OR b.city LIKE ?
                    ORDER BY b.name
                ");
                $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log("Error searching branches: " . $e->getMessage());
                return [];
            }
        }
    }

    // ✅ Additional security function for online hosting
    if (!function_exists('sanitizeInput')) {
        function sanitizeInput($data) {
            if (is_array($data)) {
                return array_map('sanitizeInput', $data);
            }
            return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
        }
    }
}
?>