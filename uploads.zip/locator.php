<?php
require_once 'config.php';

// Get all branches from database
$branches = getAllBranches();
$selectedBranch = null;

// Handle branch selection
if (isset($_GET['branch_id']) && is_numeric($_GET['branch_id'])) {
    $selectedBranch = getBranchById($_GET['branch_id']);
    if ($selectedBranch) {
        logBranchVisit($selectedBranch['id'], 'inquiry');
    }
}

// Handle AJAX requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] == 'get_branch_details') {
        $branchId = $_POST['branch_id'];
        $branch = getBranchById($branchId);
        $reviews = getBranchReviews($branchId);
        
        echo json_encode([
            'success' => true,
            'branch' => $branch,
            'reviews' => $reviews
        ]);
        exit;
    }
    
    if ($_POST['action'] == 'search_branches' && isset($_POST['query'])) {
        $results = searchBranches($_POST['query']);
        
        echo json_encode([
            'success' => true,
            'branches' => $results
        ]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOSERS BANK - Branch Locator</title>
    <link rel="icon" type="image/png" sizes="32x32" href="https://salman.rfnhsc.com/bank/uploads/losers.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://salman.rfnhsc.com/bank/uploads/losers.png">
    <link rel="shortcut icon" href="https://salman.rfnhsc.com/bank/uploads/losers.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <style>
        <?php
        // Internal SASS-like CSS with variables and nesting
        echo '
        :root {
            --primary-color: #bdb5a0;
            --secondary-color: #b21f1f;
            --accent-color: #fdbb2d;
            --light-color: #ffffff;
            --dark-color: #333333;
            --gray-light: #f8f9fa;
            --gray-medium: #6c757d;
            --gray-dark: #343a40;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --border-radius: 10px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color), var(--accent-color));
            color: var(--dark-color);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Styles */
        header {
            background: rgba(var(--light-color), 0.95);
            box-shadow: var(--box-shadow);
            border-radius: var(--border-radius);
            padding: 20px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo-container {
            display: flex;
            align-items: center;
        }

        .logo {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .logo i {
            font-size: 40px;
            color: var(--light-color);
        }

        .bank-name {
            font-size: 32px;
            font-weight: 700;
            color: var(--primary-color);
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.1);
        }

        .bank-tagline {
            font-size: 16px;
            color: var(--secondary-color);
            font-weight: 500;
        }

        /* Page Titles */
        .page-title {
            text-align: center;
            color: var(--light-color);
            margin-bottom: 30px;
            font-size: 36px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .page-subtitle {
            text-align: center;
            color: var(--light-color);
            margin-bottom: 40px;
            font-size: 20px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Main Content */
        .main-content {
            display: flex;
            gap: 30px;
            margin-bottom: 30px;
        }

        /* Branch List */
        .branch-list {
            flex: 1;
            background: rgba(var(--light-color), 0.9);
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            max-height: 600px;
            overflow-y: auto;
        }

        .branch-list h2 {
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 24px;
            border-bottom: 2px solid var(--accent-color);
            padding-bottom: 10px;
        }

        .search-box {
            margin-bottom: 20px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: var(--transition);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(var(--primary-color), 0.2);
        }

        .filter-options {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .filter-btn {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 20px;
            background: var(--light-color);
            cursor: pointer;
            transition: var(--transition);
            font-size: 14px;
        }

        .filter-btn.active {
            background: var(--primary-color);
            color: var(--light-color);
            border-color: var(--primary-color);
        }

        .filter-btn:hover {
            background: var(--primary-color);
            color: var(--light-color);
        }

        .branch-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: var(--transition);
        }

        .branch-item:hover {
            background: rgba(var(--primary-color), 0.05);
        }

        .branch-item.active {
            background: rgba(var(--primary-color), 0.1);
            border-left: 4px solid var(--primary-color);
        }

        .branch-name {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 18px;
            margin-bottom: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .branch-name .rating {
            color: var(--accent-color);
            font-size: 14px;
        }

        .branch-address {
            color: var(--gray-medium);
            font-size: 14px;
            margin-bottom: 5px;
        }

        .branch-phone {
            color: var(--secondary-color);
            font-size: 14px;
            margin-bottom: 8px;
        }

        .branch-features {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .feature {
            font-size: 12px;
            padding: 2px 8px;
            background: rgba(var(--accent-color), 0.1);
            border-radius: 10px;
            color: var(--gray-medium);
        }

        /* Branch Details */
        .branch-details {
            flex: 2;
            background: rgba(var(--light-color), 0.9);
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            min-height: 600px;
        }

        .branch-details h2 {
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 28px;
            border-bottom: 2px solid var(--accent-color);
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .branch-details h2 .rating {
            color: var(--accent-color);
            font-size: 18px;
        }

        .branch-map {
            height: 250px;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
        }

        .contact-info {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }

        .contact-item {
            flex: 1;
            min-width: 200px;
            padding: 15px;
            background: rgba(var(--accent-color), 0.1);
            border-radius: 8px;
            border-left: 4px solid var(--accent-color);
        }

        .contact-item h4 {
            color: var(--primary-color);
            margin-bottom: 8px;
            font-size: 16px;
        }

        .detail-section {
            margin-bottom: 25px;
        }

        .detail-section h3 {
            color: var(--primary-color);
            margin-bottom: 10px;
            font-size: 20px;
            display: flex;
            align-items: center;
        }

        .detail-section h3 i {
            margin-right: 10px;
            color: var(--secondary-color);
        }

        .hours-table {
            width: 100%;
            border-collapse: collapse;
        }

        .hours-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
        }

        .hours-table tr:last-child td {
            border-bottom: none;
        }

        .hours-table .day {
            font-weight: 600;
            color: var(--primary-color);
        }

        .services-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
        }

        .service-item {
            padding: 10px;
            background: rgba(var(--primary-color), 0.05);
            border-radius: 5px;
            font-size: 14px;
        }

        .service-item i {
            margin-right: 8px;
            color: var(--secondary-color);
        }

        .facilities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
        }

        .facility-item {
            text-align: center;
            padding: 15px;
            background: rgba(var(--accent-color), 0.1);
            border-radius: 8px;
        }

        .facility-item i {
            font-size: 24px;
            color: var(--primary-color);
            margin-bottom: 8px;
        }

        .facility-item.available {
            color: var(--success-color);
        }

        .facility-item.unavailable {
            color: var(--gray-medium);
            opacity: 0.5;
        }

        /* Reviews Section */
        .reviews-section {
            margin-top: 30px;
        }

        .review-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .review-author {
            font-weight: 600;
            color: var(--primary-color);
        }

        .review-rating {
            color: var(--accent-color);
        }

        .review-date {
            color: var(--gray-medium);
            font-size: 12px;
        }

        /* No Branch Selected */
        .no-branch-selected {
            text-align: center;
            padding: 50px 20px;
            color: var(--gray-medium);
        }

        .no-branch-selected i {
            font-size: 60px;
            color: #ddd;
            margin-bottom: 20px;
        }

        /* Footer */
        footer {
            background: rgba(var(--light-color), 0.9);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .footer-section {
            flex: 1;
            min-width: 250px;
            margin-bottom: 20px;
        }

        .footer-section h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 18px;
        }

        .footer-section p, .footer-section a {
            color: var(--gray-medium);
            margin-bottom: 8px;
            display: block;
            text-decoration: none;
        }

        .footer-section a:hover {
            color: var(--secondary-color);
        }

        .copyright {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: var(--gray-medium);
            font-size: 14px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }
            
            header {
                flex-direction: column;
                text-align: center;
            }
            
            .logo-container {
                margin-bottom: 15px;
                justify-content: center;
            }
            
            .branch-list {
                max-height: 400px;
            }
            
            .page-title {
                font-size: 28px;
            }
            
            .page-subtitle {
                font-size: 16px;
            }
            
            .contact-info {
                flex-direction: column;
            }
            
            .branch-details h2 {
                flex-direction: column;
                align-items: flex-start;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(var(--primary-color), 0.3);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Distance Indicator */
        .distance-indicator {
            display: inline-block;
            padding: 4px 8px;
            background: var(--success-color);
            color: var(--light-color);
            border-radius: 10px;
            font-size: 12px;
            margin-left: 10px;
        }

        /* Quick Actions */
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .action-btn {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background: var(--primary-color);
            color: var(--light-color);
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            display: inline-block;
        }

        .action-btn:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
        }
        ';
        ?>
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo-container">
                <div class="logo">
                    <i class="fas fa-university"></i>
                </div>
                <div>
                    <h1 class="bank-name">LOSERS BANK</h1>
                    <p class="bank-tagline">Your Trust, Our Responsibility - Serving Chattogram since 1995</p>
                </div>
            </div>
            <div>
                <p><i class="fas fa-phone"></i> +880 31-XXXXXX</p>
                <p><i class="fas fa-map-marker-alt"></i> Chattogram, Bangladesh</p>
            </div>
        </header>
        
        <h1 class="page-title">LOSERS BANK Branch Locator</h1>
        <p class="page-subtitle">Find your nearest LOSERS BANK branch in Chattogram and across Bangladesh. Click on any branch to view detailed information.</p>
        
        <div class="main-content">
            <div class="branch-list">
                <h2><i class="fas fa-map-marker-alt"></i> Our Branches</h2>
                
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Search by branch name or location...">
                </div>
                
                <div class="filter-options">
                    <button class="filter-btn active" data-filter="all">All</button>
                    <button class="filter-btn" data-filter="atm">ATM Available</button>
                    <button class="filter-btn" data-filter="parking">Parking</button>
                    <button class="filter-btn" data-filter="wheelchair">Wheelchair Access</button>
                </div>
                
                <div id="branchesContainer">
                    <?php if (!empty($branches)): ?>
                        <?php foreach ($branches as $branch): ?>
                            <div class="branch-item <?php echo ($selectedBranch && $selectedBranch['id'] == $branch['id']) ? 'active' : ''; ?>" 
                                 data-branch-id="<?php echo $branch['id']; ?>"
                                 data-atm="<?php echo $branch['is_atm_available'] ? 'yes' : 'no'; ?>"
                                 data-parking="<?php echo $branch['has_parking'] ? 'yes' : 'no'; ?>"
                                 data-wheelchair="<?php echo $branch['is_wheelchair_accessible'] ? 'yes' : 'no'; ?>">
                                <div class="branch-name">
                                    <?php echo htmlspecialchars($branch['name']); ?>
                                    <?php if ($branch['avg_rating'] > 0): ?>
                                        <span class="rating">
                                            <i class="fas fa-star"></i> <?php echo number_format($branch['avg_rating'], 1); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="branch-address"><?php echo htmlspecialchars($branch['address']); ?></div>
                                <div class="branch-phone"><i class="fas fa-phone"></i> <?php echo htmlspecialchars($branch['phone']); ?></div>
                                <div class="branch-features">
                                    <?php if ($branch['is_atm_available']): ?>
                                        <span class="feature"><i class="fas fa-money-bill-wave"></i> ATM</span>
                                    <?php endif; ?>
                                    <?php if ($branch['has_parking']): ?>
                                        <span class="feature"><i class="fas fa-parking"></i> Parking</span>
                                    <?php endif; ?>
                                    <?php if ($branch['is_wheelchair_accessible']): ?>
                                        <span class="feature"><i class="fas fa-wheelchair"></i> Accessible</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-branch-selected">
                            <i class="fas fa-exclamation-triangle"></i>
                            <h3>No branches found</h3>
                            <p>Please check your database connection and ensure the branches table exists.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="branch-details">
                <div id="branchContent">
                    <?php if ($selectedBranch): ?>
                        <div class="branch-detail active">
                            <h2>
                                <?php echo htmlspecialchars($selectedBranch['name']); ?>
                                <?php if ($selectedBranch['avg_rating'] > 0): ?>
                                    <span class="rating">
                                        <i class="fas fa-star"></i> <?php echo number_format($selectedBranch['avg_rating'], 1); ?>
                                        (<?php echo $selectedBranch['review_count'] ?: 0; ?> reviews)
                                    </span>
                                <?php endif; ?>
                            </h2>
                            
                            <div class="branch-map" id="branchMap">
                                <!-- Map will be loaded here -->
                            </div>
                            
                            <div class="contact-info">
                                <div class="contact-item">
                                    <h4><i class="fas fa-map-marker-alt"></i> Address</h4>
                                    <p><?php echo htmlspecialchars($selectedBranch['address']); ?></p>
                                </div>
                                <div class="contact-item">
                                    <h4><i class="fas fa-phone"></i> Contact</h4>
                                    <p><?php echo htmlspecialchars($selectedBranch['phone']); ?></p>
                                </div>
                                <div class="contact-item">
                                    <h4><i class="fas fa-envelope"></i> Email</h4>
                                    <p><?php echo htmlspecialchars($selectedBranch['email']); ?></p>
                                </div>
                                <div class="contact-item">
                                    <h4><i class="fas fa-user-tie"></i> Branch Manager</h4>
                                    <p><?php echo htmlspecialchars($selectedBranch['manager_name']); ?></p>
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="far fa-clock"></i> Opening Hours</h3>
                                <div class="opening-hours">
                                    <?php echo nl2br(htmlspecialchars($selectedBranch['opening_hours'])); ?>
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-concierge-bell"></i> Services Available</h3>
                                <div class="services-list">
                                    <?php
                                    $services = explode(',', $selectedBranch['services']);
                                    foreach ($services as $service):
                                    ?>
                                        <div class="service-item"><i class="fas fa-check"></i> <?php echo trim(htmlspecialchars($service)); ?></div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <div class="detail-section">
                                <h3><i class="fas fa-info-circle"></i> Facilities</h3>
                                <div class="facilities-grid">
                                    <div class="facility-item <?php echo $selectedBranch['is_atm_available'] ? 'available' : 'unavailable'; ?>">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <div>ATM</div>
                                    </div>
                                    <div class="facility-item <?php echo $selectedBranch['has_parking'] ? 'available' : 'unavailable'; ?>">
                                        <i class="fas fa-parking"></i>
                                        <div>Parking</div>
                                    </div>
                                    <div class="facility-item <?php echo $selectedBranch['is_wheelchair_accessible'] ? 'available' : 'unavailable'; ?>">
                                        <i class="fas fa-wheelchair"></i>
                                        <div>Wheelchair Access</div>
                                    </div>
                                    <div class="facility-item <?php echo $selectedBranch['has_drive_thru'] ? 'available' : 'unavailable'; ?>">
                                        <i class="fas fa-car"></i>
                                        <div>Drive-thru</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="quick-actions">
                                <a href="https://maps.google.com/?q=<?php echo urlencode($selectedBranch['address']); ?>" 
                                   target="_blank" class="action-btn">
                                    <i class="fas fa-directions"></i> Get Directions
                                </a>
                                <a href="tel:<?php echo preg_replace('/[^0-9+]/', '', $selectedBranch['phone']); ?>" 
                                   class="action-btn">
                                    <i class="fas fa-phone"></i> Call Branch
                                </a>
                                <?php if (isLoggedIn()): ?>
                                    <button class="action-btn" onclick="scheduleVisit(<?php echo $selectedBranch['id']; ?>)">
                                        <i class="fas fa-calendar-check"></i> Schedule Visit
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="no-branch-selected">
                            <i class="fas fa-map-marked-alt"></i>
                            <h3>Select a branch to view details</h3>
                            <p>Click on any branch from the list to see complete information including address, contact details, opening hours, and services.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <footer>
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <p><i class="fas fa-headset"></i> Customer Service: +880 31-XXXXXX</p>
                    <p><i class="fas fa-envelope"></i> Email: info@losersbank.com</p>
                    <p><i class="fas fa-map-marker-alt"></i> Head Office: Agrabad, Chattogram</p>
                </div>
                
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <a href="index.php"><i class="fas fa-home"></i> Home</a>
                    <a href="about.php"><i class="fas fa-info-circle"></i> About Us</a>
                    <a href="services.php"><i class="fas fa-concierge-bell"></i> Services</a>
                    <a href="contact.php"><i class="fas fa-phone"></i> Contact</a>
                </div>
                
                <div class="footer-section">
                    <h3>Follow Us</h3>
                    <a href="#"><i class="fab fa-facebook"></i> Facebook</a>
                    <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
                    <a href="#"><i class="fab fa-linkedin"></i> LinkedIn</a>
                    <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; 2023 LOSERS BANK. All Rights Reserved. | Regulated by Bangladesh Bank</p>
            </div>
        </footer>
    </div>

    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isLoggedIn() ? 'true' : 'false'; ?>;

        // Branch selection functionality
        document.querySelectorAll('.branch-item').forEach(item => {
            item.addEventListener('click', function() {
                const branchId = this.getAttribute('data-branch-id');
                loadBranchDetails(branchId);
            });
        });

        // Filter functionality
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all filter buttons
                document.querySelectorAll('.filter-btn').forEach(b => {
                    b.classList.remove('active');
                });
                
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                filterBranches(filter);
            });
        });

        // Search functionality
        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const searchTerm = this.value.toLowerCase();
            
            searchTimeout = setTimeout(() => {
                if (searchTerm.length >= 2) {
                    searchBranches(searchTerm);
                } else if (searchTerm.length === 0) {
                    // Reset to show all branches
                    document.querySelectorAll('.branch-item').forEach(item => {
                        item.style.display = 'block';
                    });
                }
            }, 300);
        });

        // Load branch details via AJAX
        function loadBranchDetails(branchId) {
            // Show loading state
            const branchContent = document.getElementById('branchContent');
            branchContent.innerHTML = '<div class="no-branch-selected"><div class="loading"></div><p>Loading branch details...</p></div>';
            
            // Remove active class from all branches
            document.querySelectorAll('.branch-item').forEach(branch => {
                branch.classList.remove('active');
            });
            
            // Add active class to clicked branch
            const clickedBranch = document.querySelector(`.branch-item[data-branch-id="${branchId}"]`);
            if (clickedBranch) {
                clickedBranch.classList.add('active');
            }
            
            // AJAX request
            const formData = new FormData();
            formData.append('action', 'get_branch_details');
            formData.append('branch_id', branchId);
            
            fetch('locator.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayBranchDetails(data.branch, data.reviews);
                    updateURL(branchId);
                } else {
                    branchContent.innerHTML = '<div class="no-branch-selected"><i class="fas fa-exclamation-triangle"></i><h3>Error loading branch details</h3></div>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                branchContent.innerHTML = '<div class="no-branch-selected"><i class="fas fa-exclamation-triangle"></i><h3>Error loading branch details</h3></div>';
            });
        }

        // Display branch details
        function displayBranchDetails(branch, reviews) {
            const services = branch.services.split(',').map(service => 
                `<div class="service-item"><i class="fas fa-check"></i> ${service.trim()}</div>`
            ).join('');
            
            const facilities = `
                <div class="facility-item ${branch.is_atm_available ? 'available' : 'unavailable'}">
                    <i class="fas fa-money-bill-wave"></i>
                    <div>ATM</div>
                </div>
                <div class="facility-item ${branch.has_parking ? 'available' : 'unavailable'}">
                    <i class="fas fa-parking"></i>
                    <div>Parking</div>
                </div>
                <div class="facility-item ${branch.is_wheelchair_accessible ? 'available' : 'unavailable'}">
                    <i class="fas fa-wheelchair"></i>
                    <div>Wheelchair Access</div>
                </div>
                <div class="facility-item ${branch.has_drive_thru ? 'available' : 'unavailable'}">
                    <i class="fas fa-car"></i>
                    <div>Drive-thru</div>
                </div>
            `;
            
            const ratingHtml = branch.avg_rating > 0 ? 
                `<span class="rating"><i class="fas fa-star"></i> ${parseFloat(branch.avg_rating).toFixed(1)} (${branch.review_count || 0} reviews)</span>` : '';
            
            const branchContent = `
                <div class="branch-detail active">
                    <h2>${branch.name} ${ratingHtml}</h2>
                    
                    <div class="branch-map" id="branchMap"></div>
                    
                    <div class="contact-info">
                        <div class="contact-item">
                            <h4><i class="fas fa-map-marker-alt"></i> Address</h4>
                            <p>${branch.address}</p>
                        </div>
                        <div class="contact-item">
                            <h4><i class="fas fa-phone"></i> Contact</h4>
                            <p>${branch.phone}</p>
                        </div>
                        <div class="contact-item">
                            <h4><i class="fas fa-envelope"></i> Email</h4>
                            <p>${branch.email}</p>
                        </div>
                        <div class="contact-item">
                            <h4><i class="fas fa-user-tie"></i> Branch Manager</h4>
                            <p>${branch.manager_name}</p>
                        </div>
                    </div>
                    
                    <div class="detail-section">
                        <h3><i class="far fa-clock"></i> Opening Hours</h3>
                        <div class="opening-hours">${branch.opening_hours.replace(/\n/g, '<br>')}</div>
                    </div>
                    
                    <div class="detail-section">
                        <h3><i class="fas fa-concierge-bell"></i> Services Available</h3>
                        <div class="services-list">${services}</div>
                    </div>
                    
                    <div class="detail-section">
                        <h3><i class="fas fa-info-circle"></i> Facilities</h3>
                        <div class="facilities-grid">${facilities}</div>
                    </div>
                    
                    <div class="quick-actions">
                        <a href="https://maps.google.com/?q=${encodeURIComponent(branch.address)}" target="_blank" class="action-btn">
                            <i class="fas fa-directions"></i> Get Directions
                        </a>
                        <a href="tel:${branch.phone.replace(/[^0-9+]/g, '')}" class="action-btn">
                            <i class="fas fa-phone"></i> Call Branch
                        </a>
                        ${isLoggedIn ? `<button class="action-btn" onclick="scheduleVisit(${branch.id})">
                            <i class="fas fa-calendar-check"></i> Schedule Visit
                        </button>` : ''}
                    </div>
                </div>
            `;
            
            document.getElementById('branchContent').innerHTML = branchContent;
            
            // Initialize map
            if (branch.latitude && branch.longitude) {
                initMap(parseFloat(branch.latitude), parseFloat(branch.longitude), branch.name);
            } else {
                document.getElementById('branchMap').innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100%; background: #f8f9fa; color: #6c757d;"><i class="fas fa-map-marker-alt" style="font-size: 48px; margin-right: 15px;"></i><div>Map location not available</div></div>';
            }
        }

        // Initialize Leaflet map
        function initMap(lat, lng, branchName) {
            const map = L.map('branchMap').setView([lat, lng], 15);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
            
            L.marker([lat, lng])
                .addTo(map)
                .bindPopup(`<b>${branchName}</b><br>LOSERS BANK Branch`)
                .openPopup();
        }

        // Filter branches
        function filterBranches(filter) {
            document.querySelectorAll('.branch-item').forEach(item => {
                if (filter === 'all') {
                    item.style.display = 'block';
                } else if (filter === 'atm' && item.getAttribute('data-atm') === 'yes') {
                    item.style.display = 'block';
                } else if (filter === 'parking' && item.getAttribute('data-parking') === 'yes') {
                    item.style.display = 'block';
                } else if (filter === 'wheelchair' && item.getAttribute('data-wheelchair') === 'yes') {
                    item.style.display = 'block';
                } else if (filter !== 'all') {
                    item.style.display = 'none';
                }
            });
        }

        // Search branches
        function searchBranches(query) {
            const formData = new FormData();
            formData.append('action', 'search_branches');
            formData.append('query', query);
            
            fetch('locator.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displaySearchResults(data.branches);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        // Display search results
        function displaySearchResults(branches) {
            const container = document.getElementById('branchesContainer');
            
            if (branches.length === 0) {
                container.innerHTML = '<div class="no-branch-selected"><i class="fas fa-search"></i><h3>No branches found</h3><p>Try different search terms</p></div>';
                return;
            }
            
            let html = '';
            
            branches.forEach(branch => {
                html += `
                    <div class="branch-item" data-branch-id="${branch.id}"
                         data-atm="${branch.is_atm_available ? 'yes' : 'no'}"
                         data-parking="${branch.has_parking ? 'yes' : 'no'}"
                         data-wheelchair="${branch.is_wheelchair_accessible ? 'yes' : 'no'}">
                        <div class="branch-name">
                            ${branch.name}
                            ${branch.avg_rating > 0 ? `<span class="rating"><i class="fas fa-star"></i> ${parseFloat(branch.avg_rating).toFixed(1)}</span>` : ''}
                        </div>
                        <div class="branch-address">${branch.address}</div>
                        <div class="branch-phone"><i class="fas fa-phone"></i> ${branch.phone}</div>
                        <div class="branch-features">
                            ${branch.is_atm_available ? '<span class="feature"><i class="fas fa-money-bill-wave"></i> ATM</span>' : ''}
                            ${branch.has_parking ? '<span class="feature"><i class="fas fa-parking"></i> Parking</span>' : ''}
                            ${branch.is_wheelchair_accessible ? '<span class="feature"><i class="fas fa-wheelchair"></i> Accessible</span>' : ''}
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
            
            // Re-attach event listeners
            document.querySelectorAll('.branch-item').forEach(item => {
                item.addEventListener('click', function() {
                    const branchId = this.getAttribute('data-branch-id');
                    loadBranchDetails(branchId);
                });
            });
        }

        // Update URL without reloading page
        function updateURL(branchId) {
            const url = new URL(window.location);
            url.searchParams.set('branch_id', branchId);
            window.history.pushState({}, '', url);
        }

        // Schedule visit function
        function scheduleVisit(branchId) {
            alert('Visit scheduling feature would open for branch ID: ' + branchId + '\\nIn a real implementation, this would open a modal or redirect to a scheduling page.');
        }

        // Initialize map for selected branch on page load
        <?php if ($selectedBranch && $selectedBranch['latitude'] && $selectedBranch['longitude']): ?>
            document.addEventListener('DOMContentLoaded', function() {
                initMap(<?php echo $selectedBranch['latitude']; ?>, <?php echo $selectedBranch['longitude']; ?>, '<?php echo addslashes($selectedBranch['name']); ?>');
            });
        <?php endif; ?>
    </script>
</body>
</html>