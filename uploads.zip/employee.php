<?php
// employee.php
require 'config.php';

redirectIfNotLoggedIn();

// Add logout functionality
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header('Location: login.php');
    exit();
}

$employee_id = $_SESSION['user_id'];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Prevent resubmission by checking if action was already processed
    $action_key = 'last_action_' . $action;
    if (isset($_SESSION[$action_key]) && time() - $_SESSION[$action_key] < 5) {
        $_SESSION['error_message'] = "This action was already processed. Please wait a moment before trying again.";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
    
    $_SESSION[$action_key] = time();
    
    switch($action) {
        case 'approve_registration':
            $registration_id = $_POST['registration_id'];
            approveRegistration($registration_id, $employee_id);
            break;
            
        case 'reject_registration':
            $registration_id = $_POST['registration_id'];
            $reason = $_POST['reason'] ?? 'No reason provided';
            rejectRegistration($registration_id, $employee_id, $reason);
            break;
            
        case 'create_account':
            $user_id = $_POST['user_id'];
            $account_type = $_POST['account_type'];
            $branch_id = $_POST['branch_id'];
            $initial_deposit = $_POST['initial_deposit'];
            createAccount($user_id, $account_type, $branch_id, $initial_deposit, $employee_id);
            break;
            
        case 'update_loan_status':
            $loan_id = $_POST['loan_id'];
            $status = $_POST['status'];
            updateLoanStatus($loan_id, $status, $employee_id);
            break;
            
        case 'create_transaction':
            $account_id = $_POST['account_id'];
            $type = $_POST['type'];
            $amount = $_POST['amount'];
            $description = $_POST['description'];
            createTransaction($account_id, $type, $amount, $description, $employee_id);
            break;
            
        case 'update_account_status':
            $account_id = $_POST['account_id'];
            $status = $_POST['status'];
            updateAccountStatus($account_id, $status, $employee_id);
            break;
            
        case 'update_customer_status':
            $customer_id = $_POST['customer_id'];
            $status = $_POST['status'];
            updateCustomerStatus($customer_id, $status, $employee_id);
            break;
            
        case 'create_loan':
            $user_id = $_POST['user_id'];
            $loan_type = $_POST['loan_type'];
            $amount = $_POST['amount'];
            $interest_rate = $_POST['interest_rate'];
            $term_months = $_POST['term_months'];
            createLoan($user_id, $loan_type, $amount, $interest_rate, $term_months, $employee_id);
            break;
            
        case 'create_task':
            $title = $_POST['title'];
            $description = $_POST['description'];
            $assigned_to = $_POST['assigned_to'];
            $priority = $_POST['priority'];
            $due_date = $_POST['due_date'];
            createTask($title, $description, $assigned_to, $priority, $due_date, $employee_id);
            break;
            
        case 'update_task_status':
            $task_id = $_POST['task_id'];
            $status = $_POST['status'];
            updateTaskStatus($task_id, $status, $employee_id);
            break;
            
        case 'create_report':
            $report_type = $_POST['report_type'];
            $start_date = $_POST['start_date'];
            $end_date = $_POST['end_date'];
            createReport($report_type, $start_date, $end_date, $employee_id);
            break;
            
        case 'send_message':
            $recipient_id = $_POST['recipient_id'];
            $subject = $_POST['subject'];
            $message = $_POST['message'];
            sendMessage($recipient_id, $subject, $message, $employee_id);
            break;
            
        case 'update_profile':
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            updateProfile($employee_id, $first_name, $last_name, $email, $phone, $address);
            break;
            
        case 'update_security':
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            updateSecurity($employee_id, $current_password, $new_password);
            break;
            
        // New actions for enhanced features
        case 'process_deposit':
            $account_id = $_POST['account_id'];
            $amount = $_POST['amount'];
            $description = $_POST['description'];
            processDeposit($account_id, $amount, $description, $employee_id);
            break;
            
        case 'process_withdrawal':
            $account_id = $_POST['account_id'];
            $amount = $_POST['amount'];
            $description = $_POST['description'];
            processWithdrawal($account_id, $amount, $description, $employee_id);
            break;
            
        case 'process_transfer':
            $from_account_id = $_POST['from_account_id'];
            $to_account_id = $_POST['to_account_id'];
            $amount = $_POST['amount'];
            $description = $_POST['description'];
            processTransfer($from_account_id, $to_account_id, $amount, $description, $employee_id);
            break;
            
        case 'respond_to_ticket':
            $ticket_id = $_POST['ticket_id'];
            $response = $_POST['response'];
            respondToTicket($ticket_id, $response, $employee_id);
            break;
            
        case 'update_ticket_status':
            $ticket_id = $_POST['ticket_id'];
            $status = $_POST['status'];
            updateTicketStatus($ticket_id, $status, $employee_id);
            break;
            
        case 'make_loan_payment':
            $loan_id = $_POST['loan_id'];
            $amount = $_POST['amount'];
            makeLoanPayment($loan_id, $amount, $employee_id);
            break;
            
        case 'activate_loan':
            $loan_id = $_POST['loan_id'];
            activateLoan($loan_id, $employee_id);
            break;
            
        case 'upload_profile_picture':
            uploadProfilePicture($employee_id);
            break;
            
        case 'send_customer_message':
            $customer_id = $_POST['customer_id'];
            $message = $_POST['message'];
            sendCustomerMessage($customer_id, $message, $employee_id);
            break;
            
        // Employee messaging actions
        case 'send_employee_message':
            $recipient_id = $_POST['recipient_id'];
            $subject = $_POST['subject'];
            $message = $_POST['message'];
            sendEmployeeMessage($recipient_id, $subject, $message, $employee_id);
            break;
            
        case 'mark_message_read':
            $message_id = $_POST['message_id'];
            markMessageAsRead($message_id, $employee_id);
            break;
            
        case 'mark_all_messages_read':
            markAllMessagesAsRead($employee_id);
            break;
            
        case 'delete_employee_message':
            $message_id = $_POST['message_id'];
            deleteEmployeeMessage($message_id, $employee_id);
            break;
    }
    
    // Redirect to prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// Get real-time data
$pending_registrations = $pdo->query("
    SELECT pr.*, b.name as branch_name, at.name as account_type_name 
    FROM s_pending_registrations pr 
    JOIN branches b ON pr.branch_id = b.id 
    JOIN account_types at ON pr.account_type_id = at.id 
    WHERE pr.status = 'pending'
")->fetchAll(PDO::FETCH_ASSOC);

$pending_loans = $pdo->query("
    SELECT l.*, u.first_name, u.last_name 
    FROM loans l 
    JOIN users u ON l.user_id = u.id 
    WHERE l.status = 'pending'
")->fetchAll(PDO::FETCH_ASSOC);

$recent_transactions = $pdo->query("
    SELECT t.*, a.account_number, u.first_name, u.last_name 
    FROM transactions t 
    JOIN accounts a ON t.account_id = a.id 
    JOIN users u ON a.user_id = u.id 
    ORDER BY t.created_at DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

$assigned_customers = $pdo->query("
    SELECT u.*, COUNT(a.id) as account_count 
    FROM users u 
    LEFT JOIN accounts a ON u.id = a.user_id 
    WHERE u.role = 'customer' 
    GROUP BY u.id 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

$all_customers = $pdo->query("
    SELECT u.*, COUNT(a.id) as account_count 
    FROM users u 
    LEFT JOIN accounts a ON u.id = a.user_id 
    WHERE u.role = 'customer' 
    GROUP BY u.id
")->fetchAll(PDO::FETCH_ASSOC);

$all_accounts = $pdo->query("
    SELECT a.*, u.first_name, u.last_name, at.name as account_type, b.name as branch_name 
    FROM accounts a 
    JOIN users u ON a.user_id = u.id 
    JOIN account_types at ON a.account_type_id = at.id 
    JOIN branches b ON a.branch_id = b.id 
    ORDER BY a.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

$all_loans = $pdo->query("
    SELECT l.*, u.first_name, u.last_name 
    FROM loans l 
    JOIN users u ON l.user_id = u.id 
    ORDER BY l.applied_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

$all_transactions = $pdo->query("
    SELECT t.*, a.account_number, u.first_name, u.last_name 
    FROM transactions t 
    JOIN accounts a ON t.account_id = a.id 
    JOIN users u ON a.user_id = u.id 
    ORDER BY t.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

$employee_tasks = $pdo->query("
    SELECT t.*, u.first_name, u.last_name as assignee_name 
    FROM s_employee_tasks t 
    JOIN users u ON t.assigned_to = u.id 
    WHERE t.assigned_to = $employee_id OR t.assigned_by = $employee_id
    ORDER BY t.due_date ASC
")->fetchAll(PDO::FETCH_ASSOC);

$all_employees = $pdo->query("
    SELECT id, first_name, last_name 
    FROM users 
    WHERE role = 'employee' AND id != $employee_id
")->fetchAll(PDO::FETCH_ASSOC);

$account_types = $pdo->query("SELECT * FROM account_types")->fetchAll(PDO::FETCH_ASSOC);
$branches = $pdo->query("SELECT * FROM branches")->fetchAll(PDO::FETCH_ASSOC);

// New data for enhanced features
$customer_tickets = $pdo->query("
    SELECT cst.*, u.first_name, u.last_name, u.email 
    FROM customer_service_tickets cst 
    JOIN users u ON cst.user_id = u.id 
    WHERE cst.status IN ('open', 'in progress') OR cst.assigned_to = $employee_id
    ORDER BY cst.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

$customer_feedback = $pdo->query("
    SELECT f.*, u.first_name, u.last_name 
    FROM feedback f 
    JOIN users u ON f.user_id = u.id 
    ORDER BY f.created_at DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

$active_loans = $pdo->query("
    SELECT l.*, u.first_name, u.last_name, 
           (SELECT SUM(amount) FROM loan_payments WHERE loan_id = l.id) as total_paid,
           (l.amount - COALESCE((SELECT SUM(amount) FROM loan_payments WHERE loan_id = l.id), 0)) as remaining_balance
    FROM loans l 
    JOIN users u ON l.user_id = u.id 
    WHERE l.status = 'active'
    ORDER BY l.applied_date DESC
")->fetchAll(PDO::FETCH_ASSOC);

$customer_messages = $pdo->query("
    SELECT cm.*, u.first_name, u.last_name 
    FROM customer_messages cm 
    JOIN users u ON cm.customer_id = u.id 
    WHERE cm.status = 'unread' OR cm.responded_by = $employee_id
    ORDER BY cm.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Employee messaging data
$employee_messages = $pdo->query("
    SELECT em.*, 
           sender.first_name as sender_first_name, 
           sender.last_name as sender_last_name,
           recipient.first_name as recipient_first_name,
           recipient.last_name as recipient_last_name
    FROM employee_messages em
    JOIN users sender ON em.sender_id = sender.id
    JOIN users recipient ON em.recipient_id = recipient.id
    WHERE em.recipient_id = $employee_id OR em.sender_id = $employee_id
    ORDER BY em.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

$unread_messages_count = $pdo->query("
    SELECT COUNT(*) as count FROM employee_messages 
    WHERE recipient_id = $employee_id AND status = 'unread'
")->fetch()['count'];

// Statistics
$stats = [
    'assigned_customers' => $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'customer'")->fetch()['count'],
    'pending_loans' => $pdo->query("SELECT COUNT(*) as count FROM loans WHERE status = 'pending'")->fetch()['count'],
    'pending_registrations' => $pdo->query("SELECT COUNT(*) as count FROM s_pending_registrations WHERE status = 'pending'")->fetch()['count'],
    'today_transactions' => $pdo->query("SELECT COUNT(*) as count FROM transactions WHERE DATE(created_at) = CURDATE()")->fetch()['count'],
    'total_balance' => $pdo->query("SELECT SUM(balance) as total FROM accounts")->fetch()['total'] ?? 0,
    'total_transactions_today' => $pdo->query("SELECT SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'completed'")->fetch()['total'] ?? 0,
    'pending_tasks' => $pdo->query("SELECT COUNT(*) as count FROM s_employee_tasks WHERE assigned_to = $employee_id AND status = 'pending'")->fetch()['count'],
    'open_tickets' => $pdo->query("SELECT COUNT(*) as count FROM customer_service_tickets WHERE status IN ('open', 'in progress')")->fetch()['count'],
    'active_loans' => $pdo->query("SELECT COUNT(*) as count FROM loans WHERE status = 'active'")->fetch()['count'],
    'unread_messages' => $unread_messages_count,
];

// Functions for actions
function approveRegistration($registration_id, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Get registration data
        $stmt = $pdo->prepare("SELECT * FROM s_pending_registrations WHERE id = ?");
        $stmt->execute([$registration_id]);
        $registration = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($registration) {
            // Create user account
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, first_name, last_name, phone, address, city, nid_number, date_of_birth, status) VALUES (?, ?, ?, 'customer', ?, ?, ?, ?, ?, ?, ?, 'active')");
            $stmt->execute([
                $registration['username'],
                $registration['password'],
                $registration['email'],
                $registration['first_name'],
                $registration['last_name'],
                $registration['phone'],
                $registration['address'],
                $registration['city'],
                $registration['nid_number'],
                $registration['date_of_birth']
            ]);
            
            $user_id = $pdo->lastInsertId();
            
            // Create bank account
            $account_number = generateAccountNumber();
            $stmt = $pdo->prepare("INSERT INTO accounts (account_number, user_id, account_type_id, branch_id, balance, opened_date) VALUES (?, ?, ?, ?, ?, CURDATE())");
            $stmt->execute([
                $account_number,
                $user_id,
                $registration['account_type_id'],
                $registration['branch_id'],
                $registration['initial_deposit']
            ]);
            
            $account_id = $pdo->lastInsertId();
            
            // Create initial deposit transaction
            $transaction_id = 'TXN-' . str_pad($pdo->lastInsertId(), 6, '0', STR_PAD_LEFT);
            $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'deposit', ?, 'Initial deposit', 'completed')");
            $stmt->execute([
                $transaction_id,
                $account_id,
                $registration['initial_deposit']
            ]);
            
            // Update registration status
            $stmt = $pdo->prepare("UPDATE s_pending_registrations SET status = 'approved', approved_by = ?, approval_date = NOW() WHERE id = ?");
            $stmt->execute([$employee_id, $registration_id]);
            
            $pdo->commit();
            
            // Log action
            logAction('REGISTRATION_APPROVED', "Approved registration for: " . $registration['username']);
            addAuditTrail('s_pending_registrations', $registration_id, 'UPDATE', ['status' => 'pending'], ['status' => 'approved']);
            
            $_SESSION['success_message'] = "Registration approved successfully! Account created for " . $registration['username'];
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error approving registration: " . $e->getMessage();
    }
}

function rejectRegistration($registration_id, $employee_id, $reason) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE s_pending_registrations SET status = 'rejected', approved_by = ?, approval_date = NOW(), rejection_reason = ? WHERE id = ?");
    $stmt->execute([$employee_id, $reason, $registration_id]);
    
    logAction('REGISTRATION_REJECTED', "Rejected registration ID: $registration_id");
    $_SESSION['success_message'] = "Registration rejected successfully!";
}

function createAccount($user_id, $account_type_id, $branch_id, $initial_deposit, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $account_number = generateAccountNumber();
        $stmt = $pdo->prepare("INSERT INTO accounts (account_number, user_id, account_type_id, branch_id, balance, opened_date) VALUES (?, ?, ?, ?, ?, CURDATE())");
        $stmt->execute([
            $account_number,
            $user_id,
            $account_type_id,
            $branch_id,
            $initial_deposit
        ]);
        
        $account_id = $pdo->lastInsertId();
        
        // Create initial deposit transaction
        $transaction_id = 'TXN-' . str_pad($pdo->lastInsertId(), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'deposit', ?, 'Initial deposit', 'completed')");
        $stmt->execute([
            $transaction_id,
            $account_id,
            $initial_deposit
        ]);
        
        $pdo->commit();
        
        logAction('ACCOUNT_CREATED', "Created account: $account_number for user ID: $user_id");
        $_SESSION['success_message'] = "Account created successfully! Account Number: $account_number";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error creating account: " . $e->getMessage();
    }
}

function updateLoanStatus($loan_id, $status, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE loans SET status = ?, approved_date = CASE WHEN ? = 'approved' THEN CURDATE() ELSE approved_date END WHERE id = ?");
    $stmt->execute([$status, $status, $loan_id]);
    
    logAction('LOAN_STATUS_UPDATED', "Updated loan ID: $loan_id to status: $status");
    $_SESSION['success_message'] = "Loan status updated successfully!";
}

function createTransaction($account_id, $type, $amount, $description, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $transaction_id = 'TXN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, ?, ?, ?, 'completed')");
        $stmt->execute([
            $transaction_id,
            $account_id,
            $type,
            $amount,
            $description
        ]);
        
        // Update account balance
        if ($type == 'deposit') {
            $stmt = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?");
        } else {
            $stmt = $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?");
        }
        $stmt->execute([$amount, $account_id]);
        
        $pdo->commit();
        
        logAction('TRANSACTION_CREATED', "Created $type transaction: $transaction_id for account ID: $account_id");
        $_SESSION['success_message'] = "Transaction created successfully! Transaction ID: $transaction_id";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error creating transaction: " . $e->getMessage();
    }
}

function updateAccountStatus($account_id, $status, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE accounts SET status = ? WHERE id = ?");
    $stmt->execute([$status, $account_id]);
    
    logAction('ACCOUNT_STATUS_UPDATED', "Updated account ID: $account_id to status: $status");
    $_SESSION['success_message'] = "Account status updated successfully!";
}

function updateCustomerStatus($customer_id, $status, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->execute([$status, $customer_id]);
    
    logAction('CUSTOMER_STATUS_UPDATED', "Updated customer ID: $customer_id to status: $status");
    $_SESSION['success_message'] = "Customer status updated successfully!";
}

function createLoan($user_id, $loan_type, $amount, $interest_rate, $term_months, $employee_id) {
    global $pdo;
    
    $loan_number = 'LN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
    
    // Calculate monthly payment (simple calculation)
    $monthly_interest = $interest_rate / 100 / 12;
    $monthly_payment = ($amount * $monthly_interest * pow(1 + $monthly_interest, $term_months)) / (pow(1 + $monthly_interest, $term_months) - 1);
    
    $stmt = $pdo->prepare("INSERT INTO loans (loan_number, user_id, loan_type, amount, interest_rate, term_months, remaining_balance, monthly_payment, status, applied_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'approved', CURDATE())");
    $stmt->execute([
        $loan_number,
        $user_id,
        $loan_type,
        $amount,
        $interest_rate,
        $term_months,
        $amount,
        $monthly_payment
    ]);
    
    logAction('LOAN_CREATED', "Created loan: $loan_number for user ID: $user_id");
    $_SESSION['success_message'] = "Loan created successfully! Loan Number: $loan_number";
}

function createTask($title, $description, $assigned_to, $priority, $due_date, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO s_employee_tasks (title, description, assigned_to, assigned_by, priority, due_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $title,
        $description,
        $assigned_to,
        $employee_id,
        $priority,
        $due_date
    ]);
    
    logAction('TASK_CREATED', "Created task: $title for employee ID: $assigned_to");
    $_SESSION['success_message'] = "Task created successfully!";
}

function updateTaskStatus($task_id, $status, $employee_id) {
    global $pdo;
    
    $completed_at = ($status == 'completed') ? date('Y-m-d H:i:s') : null;
    
    $stmt = $pdo->prepare("UPDATE s_employee_tasks SET status = ?, completed_at = ? WHERE id = ?");
    $stmt->execute([$status, $completed_at, $task_id]);
    
    logAction('TASK_STATUS_UPDATED', "Updated task ID: $task_id to status: $status");
    $_SESSION['success_message'] = "Task status updated successfully!";
}

function createReport($report_type, $start_date, $end_date, $employee_id) {
    // In a real implementation, this would generate a PDF or Excel report
    // For now, we'll just log the action
    logAction('REPORT_GENERATED', "Generated $report_type report from $start_date to $end_date");
    $_SESSION['success_message'] = "Report generated successfully!";
}

function sendMessage($recipient_id, $subject, $message, $employee_id) {
    global $pdo;
    
    // Create a notification for the recipient
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, 'info')");
    $stmt->execute([$recipient_id, $subject, $message]);
    
    logAction('MESSAGE_SENT', "Sent message to user ID: $recipient_id");
    $_SESSION['success_message'] = "Message sent successfully!";
}

function updateProfile($employee_id, $first_name, $last_name, $email, $phone, $address) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->execute([$first_name, $last_name, $email, $phone, $address, $employee_id]);
    
    // Update session variables
    $_SESSION['first_name'] = $first_name;
    $_SESSION['last_name'] = $last_name;
    $_SESSION['email'] = $email;
    
    logAction('PROFILE_UPDATED', "Updated profile for employee ID: $employee_id");
    $_SESSION['success_message'] = "Profile updated successfully!";
}

function updateSecurity($employee_id, $current_password, $new_password) {
    global $pdo;
    
    // Verify current password
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$employee_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (password_verify($current_password, $user['password'])) {
        // Update password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $employee_id]);
        
        logAction('PASSWORD_CHANGED', "Changed password for employee ID: $employee_id");
        $_SESSION['success_message'] = "Password updated successfully!";
    } else {
        $_SESSION['error_message'] = "Current password is incorrect!";
    }
}

// New functions for enhanced features
function processDeposit($account_id, $amount, $description, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $transaction_id = 'TXN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'deposit', ?, ?, 'completed')");
        $stmt->execute([
            $transaction_id,
            $account_id,
            $amount,
            $description
        ]);
        
        // Update account balance
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $account_id]);
        
        $pdo->commit();
        
        logAction('DEPOSIT_PROCESSED', "Processed deposit: $transaction_id for account ID: $account_id");
        $_SESSION['success_message'] = "Deposit processed successfully! Transaction ID: $transaction_id";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error processing deposit: " . $e->getMessage();
    }
}

function processWithdrawal($account_id, $amount, $description, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Check if account has sufficient balance
        $stmt = $pdo->prepare("SELECT balance FROM accounts WHERE id = ?");
        $stmt->execute([$account_id]);
        $account = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($account['balance'] < $amount) {
            throw new Exception("Insufficient balance in account");
        }
        
        $transaction_id = 'TXN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'withdrawal', ?, ?, 'completed')");
        $stmt->execute([
            $transaction_id,
            $account_id,
            $amount,
            $description
        ]);
        
        // Update account balance
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$amount, $account_id]);
        
        $pdo->commit();
        
        logAction('WITHDRAWAL_PROCESSED', "Processed withdrawal: $transaction_id for account ID: $account_id");
        $_SESSION['success_message'] = "Withdrawal processed successfully! Transaction ID: $transaction_id";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error processing withdrawal: " . $e->getMessage();
    }
}

function processTransfer($from_account_id, $to_account_id, $amount, $description, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Check if from account has sufficient balance
        $stmt = $pdo->prepare("SELECT balance FROM accounts WHERE id = ?");
        $stmt->execute([$from_account_id]);
        $from_account = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($from_account['balance'] < $amount) {
            throw new Exception("Insufficient balance in source account");
        }
        
        // Check if to account exists
        $stmt = $pdo->prepare("SELECT id FROM accounts WHERE id = ?");
        $stmt->execute([$to_account_id]);
        $to_account = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$to_account) {
            throw new Exception("Destination account not found");
        }
        
        // Create withdrawal transaction
        $withdrawal_id = 'TXN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'withdrawal', ?, ?, 'completed')");
        $stmt->execute([
            $withdrawal_id,
            $from_account_id,
            $amount,
            "Transfer to account: " . $to_account_id . " - " . $description
        ]);
        
        // Create deposit transaction
        $deposit_id = 'TXN-' . str_pad(rand(100000, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, account_id, type, amount, description, status) VALUES (?, ?, 'deposit', ?, ?, 'completed')");
        $stmt->execute([
            $deposit_id,
            $to_account_id,
            $amount,
            "Transfer from account: " . $from_account_id . " - " . $description
        ]);
        
        // Update account balances
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$amount, $from_account_id]);
        
        $stmt = $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $to_account_id]);
        
        $pdo->commit();
        
        logAction('TRANSFER_PROCESSED', "Processed transfer from account: $from_account_id to account: $to_account_id");
        $_SESSION['success_message'] = "Transfer processed successfully!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error processing transfer: " . $e->getMessage();
    }
}

function respondToTicket($ticket_id, $response, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE customer_service_tickets SET response = ?, status = 'in progress', assigned_to = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$response, $employee_id, $ticket_id]);
    
    logAction('TICKET_RESPONDED', "Responded to ticket ID: $ticket_id");
    $_SESSION['success_message'] = "Response sent successfully!";
}

function updateTicketStatus($ticket_id, $status, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE customer_service_tickets SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $ticket_id]);
    
    logAction('TICKET_STATUS_UPDATED', "Updated ticket ID: $ticket_id to status: $status");
    $_SESSION['success_message'] = "Ticket status updated successfully!";
}

function makeLoanPayment($loan_id, $amount, $employee_id) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Get loan details
        $stmt = $pdo->prepare("SELECT * FROM loans WHERE id = ?");
        $stmt->execute([$loan_id]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$loan) {
            throw new Exception("Loan not found");
        }
        
        // Create loan payment
        $stmt = $pdo->prepare("INSERT INTO loan_payments (loan_id, amount) VALUES (?, ?)");
        $stmt->execute([$loan_id, $amount]);
        
        // Update loan remaining balance
        $new_balance = $loan['remaining_balance'] - $amount;
        $status = ($new_balance <= 0) ? 'paid' : 'active';
        
        $stmt = $pdo->prepare("UPDATE loans SET remaining_balance = ?, status = ? WHERE id = ?");
        $stmt->execute([$new_balance, $status, $loan_id]);
        
        $pdo->commit();
        
        logAction('LOAN_PAYMENT_MADE', "Made payment of $amount for loan ID: $loan_id");
        $_SESSION['success_message'] = "Loan payment processed successfully!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error_message'] = "Error processing loan payment: " . $e->getMessage();
    }
}

function activateLoan($loan_id, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE loans SET status = 'active' WHERE id = ?");
    $stmt->execute([$loan_id]);
    
    logAction('LOAN_ACTIVATED', "Activated loan ID: $loan_id");
    $_SESSION['success_message'] = "Loan activated successfully!";
}

function uploadProfilePicture($employee_id) {
    global $pdo;
    
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES['profile_picture']['tmp_name'];
        $file_name = $_FILES['profile_picture']['name'];
        $file_size = $_FILES['profile_picture']['size'];
        $file_type = $_FILES['profile_picture']['type'];
        
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        $max_file_size = 5 * 1024 * 1024; // 5MB
        
        if (in_array($file_type, $allowed_types) && $file_size <= $max_file_size) {
            $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
            $new_file_name = 'profile_' . $employee_id . '_' . time() . '.' . $file_extension;
            $upload_dir = 'uploads/profile_pictures/';
            
            // Create directory if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $dest_path = $upload_dir . $new_file_name;
            
            if (move_uploaded_file($file_tmp_path, $dest_path)) {
                // Update database
                $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                $stmt->execute([$dest_path, $employee_id]);
                
                // Update session
                $_SESSION['profile_picture'] = $dest_path;
                
                logAction('PROFILE_PICTURE_UPDATED', "Updated profile picture for employee ID: $employee_id");
                $_SESSION['success_message'] = "Profile picture updated successfully!";
            } else {
                $_SESSION['error_message'] = "Error uploading file";
            }
        } else {
            $_SESSION['error_message'] = "Invalid file type or size. Only JPG, PNG, GIF up to 5MB are allowed.";
        }
    } else {
        $_SESSION['error_message'] = "No file uploaded or upload error";
    }
}

function sendCustomerMessage($customer_id, $message, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO customer_messages (customer_id, message, responded_by, status) VALUES (?, ?, ?, 'responded')");
    $stmt->execute([$customer_id, $message, $employee_id]);
    
    logAction('CUSTOMER_MESSAGE_SENT', "Sent message to customer ID: $customer_id");
    $_SESSION['success_message'] = "Message sent to customer successfully!";
}

// Employee messaging functions
function sendEmployeeMessage($recipient_id, $subject, $message, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO employee_messages (sender_id, recipient_id, subject, message, status) VALUES (?, ?, ?, ?, 'unread')");
    $stmt->execute([$employee_id, $recipient_id, $subject, $message]);
    
    logAction('EMPLOYEE_MESSAGE_SENT', "Sent message to employee ID: $recipient_id");
    $_SESSION['success_message'] = "Message sent successfully!";
}

function markMessageAsRead($message_id, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE employee_messages SET status = 'read' WHERE id = ? AND recipient_id = ?");
    $stmt->execute([$message_id, $employee_id]);
    
    logAction('MESSAGE_MARKED_READ', "Marked message ID: $message_id as read");
    $_SESSION['success_message'] = "Message marked as read!";
}

function markAllMessagesAsRead($employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE employee_messages SET status = 'read' WHERE recipient_id = ? AND status = 'unread'");
    $stmt->execute([$employee_id]);
    
    logAction('ALL_MESSAGES_MARKED_READ', "Marked all messages as read for employee ID: $employee_id");
    $_SESSION['success_message'] = "All messages marked as read!";
}

function deleteEmployeeMessage($message_id, $employee_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("DELETE FROM employee_messages WHERE id = ? AND (sender_id = ? OR recipient_id = ?)");
    $stmt->execute([$message_id, $employee_id, $employee_id]);
    
    logAction('EMPLOYEE_MESSAGE_DELETED', "Deleted message ID: $message_id");
    $_SESSION['success_message'] = "Message deleted successfully!";
}

function generateAccountNumber() {
    return '00' . str_pad(rand(1, 99999999999), 11, '0', STR_PAD_LEFT);
}

// Helper functions from config.php
function logAction($action, $description) {
    global $pdo, $employee_id;
    
    $stmt = $pdo->prepare("INSERT INTO s_system_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$employee_id, $action, $description, $_SERVER['REMOTE_ADDR']]);
}

function addAuditTrail($table_name, $record_id, $action, $old_values, $new_values) {
    global $pdo, $employee_id;
    
    $stmt = $pdo->prepare("INSERT INTO s_audit_trail (table_name, record_id, action, old_values, new_values, changed_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$table_name, $record_id, $action, json_encode($old_values), json_encode($new_values), $employee_id]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOSERS BANK - Employee Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        /* All CSS styles from the enhanced version */
        :root {
            --primary: #2980b9;
            --secondary: #3498db;
            --accent: #1abc9c;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #9b59b6;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --sidebar-width: 260px;
            --header-height: 70px;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }
        
        .dark-mode {
            --primary: #34495e;
            --secondary: #2c3e50;
            --light: #2c3e50;
            --dark: #ecf0f1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            transition: var(--transition);
            overflow-x: hidden;
        }

        body.dark-mode {
            background-color: #1a2530;
            color: #ecf0f1;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(to bottom, var(--primary), var(--secondary));
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: var(--transition);
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            height: var(--header-height);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background-color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-weight: bold;
            font-size: 18px;
        }

        .logo h1 {
            font-size: 20px;
            font-weight: 700;
        }

        .employee-info {
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .employee-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--info));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 20px;
            margin: 0 auto 10px;
            border: 3px solid rgba(255, 255, 255, 0.2);
            background-size: cover;
            background-position: center;
        }

        .employee-name {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .employee-role {
            font-size: 12px;
            opacity: 0.8;
        }

        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }

        .menu-section {
            padding: 0 20px;
            margin-top: 20px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255, 255, 255, 0.6);
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: var(--transition);
            border-left: 4px solid transparent;
            cursor: pointer;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            border-left: 4px solid var(--accent);
        }

        .sidebar-menu i {
            margin-right: 15px;
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        .menu-badge {
            margin-left: auto;
            background-color: var(--danger);
            color: white;
            border-radius: 10px;
            padding: 2px 8px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: var(--transition);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
            padding: 0 25px;
            height: var(--header-height);
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 100;
            transition: var(--transition);
        }

        body.dark-mode .header {
            background-color: var(--primary);
        }

        .header-left h2 {
            color: var(--primary);
            font-weight: 600;
        }

        body.dark-mode .header-left h2 {
            color: white;
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .theme-toggle {
            margin-right: 20px;
            cursor: pointer;
            font-size: 20px;
            color: var(--dark);
        }

        body.dark-mode .theme-toggle {
            color: white;
        }

        .notification-icon {
            position: relative;
            margin-right: 25px;
            font-size: 20px;
            color: var(--dark);
            cursor: pointer;
        }

        body.dark-mode .notification-icon {
            color: white;
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-profile {
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--info));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            margin-right: 10px;
            background-size: cover;
            background-position: center;
        }

        /* Content Area */
        .content {
            padding: 25px;
        }

        /* Section Styles */
        .section {
            display: none;
            animation: fadeIn 0.5s ease;
        }

        .section.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .section-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
        }

        body.dark-mode .section-title {
            color: white;
        }

        .section-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 10px 20px;
            border-radius: var(--border-radius);
            border: none;
            cursor: pointer;
            font-weight: 500;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background-color: var(--accent);
            color: white;
        }

        .btn-success {
            background-color: var(--success);
            color: white;
        }

        .btn-danger {
            background-color: var(--danger);
            color: white;
        }

        .btn-warning {
            background-color: var(--warning);
            color: white;
        }

        .btn-info {
            background-color: var(--info);
            color: white;
        }

        .btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            transition: var(--transition);
            border-top: 4px solid var(--accent);
        }

        body.dark-mode .stat-card {
            background-color: var(--primary);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-title {
            font-size: 14px;
            color: var(--dark);
            font-weight: 500;
        }

        body.dark-mode .stat-title {
            color: rgba(255, 255, 255, 0.7);
        }

        .stat-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }

        .customers .stat-icon {
            background-color: var(--accent);
        }

        .transactions .stat-icon {
            background-color: var(--info);
        }

        .loans .stat-icon {
            background-color: var(--warning);
        }

        .accounts .stat-icon {
            background-color: var(--success);
        }

        .alerts .stat-icon {
            background-color: var(--danger);
        }

        .attendance .stat-icon {
            background-color: #9b59b6;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-change {
            font-size: 12px;
            display: flex;
            align-items: center;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Table Styles */
        .table-container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
            margin-bottom: 30px;
        }

        body.dark-mode .table-container {
            background-color: var(--primary);
        }

        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        body.dark-mode th, body.dark-mode td {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--dark);
        }

        body.dark-mode th {
            background-color: rgba(255, 255, 255, 0.05);
            color: white;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        body.dark-mode tr:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }

        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-active {
            background-color: rgba(46, 204, 113, 0.2);
            color: var(--success);
        }

        .status-pending {
            background-color: rgba(243, 156, 18, 0.2);
            color: var(--warning);
        }

        .status-suspended {
            background-color: rgba(231, 76, 60, 0.2);
            color: var(--danger);
        }

        .status-completed {
            background-color: rgba(46, 204, 113, 0.2);
            color: var(--success);
        }

        /* Form Styles */
        .form-container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 25px;
            margin-bottom: 30px;
        }

        body.dark-mode .form-container {
            background-color: var(--primary);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }

        body.dark-mode .form-label {
            color: white;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border-radius: var(--border-radius);
            border: 1px solid #ddd;
            background-color: white;
            transition: var(--transition);
        }

        body.dark-mode .form-control {
            background-color: var(--secondary);
            border-color: var(--secondary);
            color: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }

        /* Grid Layouts */
        .grid-2 {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .grid-3 {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        /* Card Styles */
        .card {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            transition: var(--transition);
        }

        body.dark-mode .card {
            background-color: var(--primary);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        body.dark-mode .card-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary);
        }

        body.dark-mode .card-title {
            color: white;
        }

        /* Charts Section */
        .charts-row {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 20px;
            transition: var(--transition);
        }

        body.dark-mode .chart-container {
            background-color: var(--primary);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .chart-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark);
        }

        body.dark-mode .chart-title {
            color: white;
        }

        .chart-actions {
            display: flex;
            gap: 10px;
        }

        .chart-actions select {
            padding: 5px 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
            background-color: white;
        }

        body.dark-mode .chart-actions select {
            background-color: var(--secondary);
            border-color: var(--secondary);
            color: white;
        }

        .chart-wrapper {
            height: 300px;
            position: relative;
        }

        /* Mobile Menu Toggle */
        .mobile-menu-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 24px;
            color: var(--dark);
            cursor: pointer;
            margin-right: 15px;
        }

        body.dark-mode .mobile-menu-toggle {
            color: white;
        }

        /* Utility Classes */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .mb-20 { margin-bottom: 20px; }
        .mt-20 { margin-top: 20px; }
        .p-20 { padding: 20px; }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: var(--border-radius);
            width: 90%;
            max-width: 500px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        body.dark-mode .modal-content {
            background: var(--primary);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        body.dark-mode .modal-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #eee;
        }
        
        body.dark-mode .modal-footer {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--dark);
        }
        
        body.dark-mode .close-modal {
            color: white;
        }
        
        .success-message, .error-message {
            padding: 15px;
            margin: 15px 0;
            border-radius: var(--border-radius);
            font-weight: 500;
        }
        
        .success-message {
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }
        
        .error-message {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu-toggle {
                display: block;
            }
            
            .charts-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 992px) {
            .stats-cards {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .section-actions {
                width: 100%;
                justify-content: flex-start;
            }
            
            .grid-2, .grid-3 {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            .content {
                padding: 15px;
            }
            
            .header {
                padding: 0 15px;
            }
            
            .user-profile .user-name {
                display: none;
            }
            
            th, td {
                padding: 10px;
                font-size: 14px;
            }
        }

        @media (max-width: 576px) {
            .btn {
                padding: 8px 15px;
                font-size: 14px;
            }
            
            .section-title {
                font-size: 20px;
            }
            
            .chart-wrapper {
                height: 250px;
            }
            
            .section-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .section-actions .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon">LB</div>
                <h1>LOSERS BANK</h1>
            </div>
            
            <div class="employee-info">
                <div class="employee-avatar" style="background-image: url('<?php echo $_SESSION['profile_picture'] ?? ''; ?>');">
                    <?php if(empty($_SESSION['profile_picture'])): ?>
                        <?php echo substr($_SESSION['first_name'], 0, 1) . substr($_SESSION['last_name'], 0, 1); ?>
                    <?php endif; ?>
                </div>
                <div class="employee-name"><?php echo $_SESSION['first_name'] . ' ' . $_SESSION['last_name']; ?></div>
                <div class="employee-role">Senior Banking Officer</div>
            </div>
            
            <ul class="sidebar-menu">
                <div class="menu-section">Main</div>
                <li><a class="menu-link active" data-section="dashboard"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                
                <div class="menu-section">Customer Management</div>
                <li><a class="menu-link" data-section="registrations"><i class="fas fa-user-plus"></i> <span>Registrations</span> <span class="menu-badge"><?php echo $stats['pending_registrations']; ?></span></a></li>
                <li><a class="menu-link" data-section="customers"><i class="fas fa-users"></i> <span>Customers</span></a></li>
                <li><a class="menu-link" data-section="accounts"><i class="fas fa-university"></i> <span>Accounts</span></a></li>
                
                <div class="menu-section">Transactions & Loans</div>
                <li><a class="menu-link" data-section="transactions"><i class="fas fa-exchange-alt"></i> <span>Transactions</span></a></li>
                <li><a class="menu-link" data-section="deposits-withdrawals"><i class="fas fa-money-bill-wave"></i> <span>Deposits/Withdrawals</span></a></li>
                <li><a class="menu-link" data-section="loans"><i class="fas fa-hand-holding-usd"></i> <span>Loans</span> <span class="menu-badge"><?php echo $stats['pending_loans']; ?></span></a></li>
                
                <div class="menu-section">Customer Service</div>
                <li><a class="menu-link" data-section="customer-care"><i class="fas fa-headset"></i> <span>Customer Care</span> <span class="menu-badge"><?php echo $stats['open_tickets']; ?></span></a></li>
                <li><a class="menu-link" data-section="feedback"><i class="fas fa-comment-dots"></i> <span>Feedback</span></a></li>
                
                <div class="menu-section">Reports & Tools</div>
                <li><a class="menu-link" data-section="reports"><i class="fas fa-chart-bar"></i> <span>Reports</span></a></li>
                <li><a class="menu-link" data-section="tasks"><i class="fas fa-tasks"></i> <span>Tasks</span> <span class="menu-badge"><?php echo $stats['pending_tasks']; ?></span></a></li>
                
                <div class="menu-section">Communication</div>
                <li><a class="menu-link" data-section="communication"><i class="fas fa-comments"></i> <span>Customer Messages</span> <span class="menu-badge"><?php echo $stats['unread_messages']; ?></span></a></li>
                <li><a class="menu-link" data-section="employee-messages"><i class="fas fa-envelope"></i> <span>Employee Messages</span> <span class="menu-badge"><?php echo $unread_messages_count; ?></span></a></li>
                
                <div class="menu-section">Settings</div>
                <li><a class="menu-link" data-section="profile"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
                <li><a class="menu-link" data-section="security"><i class="fas fa-shield-alt"></i> <span>Security</span></a></li>
                <li><a href="logout.php" class="menu-link"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <div class="header-left">
                    <button class="mobile-menu-toggle" id="mobileMenuToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2 id="pageTitle">Employee Dashboard</h2>
                </div>
                <div class="header-right">
                    <div class="theme-toggle" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </div>
                    <div class="notification-icon">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge"><?php echo $stats['pending_registrations'] + $stats['pending_loans'] + $stats['pending_tasks'] + $stats['open_tickets'] + $stats['unread_messages'] + $unread_messages_count; ?></span>
                    </div>
                    <div class="user-profile">
                        <div class="profile-pic" style="background-image: url('<?php echo $_SESSION['profile_picture'] ?? ''; ?>');">
                            <?php if(empty($_SESSION['profile_picture'])): ?>
                                <?php echo substr($_SESSION['first_name'], 0, 1) . substr($_SESSION['last_name'], 0, 1); ?>
                            <?php endif; ?>
                        </div>
                        <div class="user-name"><?php echo $_SESSION['first_name'] . ' ' . $_SESSION['last_name']; ?></div>
                    </div>
                </div>
            </div>

            <!-- Content Area -->
            <div class="content">
                <!-- Success/Error Messages -->
                <?php if (isset($_SESSION['success_message'])): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error_message'])): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                </div>
                <?php endif; ?>

                <!-- Dashboard Section -->
                <div class="section active" id="dashboard">
                    <div class="section-header">
                        <div class="section-title">Dashboard Overview</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="refreshData()"><i class="fas fa-sync-alt"></i> Refresh Data</button>
                            <button class="btn btn-success" onclick="exportReport()"><i class="fas fa-download"></i> Export Report</button>
                        </div>
                    </div>

                    <!-- Stats Cards -->
                    <div class="stats-cards">
                        <div class="stat-card customers">
                            <div class="stat-header">
                                <div class="stat-title">Assigned Customers</div>
                                <div class="stat-icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                            <div class="stat-value"><?php echo $stats['assigned_customers']; ?></div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i> 12% from last month
                            </div>
                        </div>
                        
                        <div class="stat-card transactions">
                            <div class="stat-header">
                                <div class="stat-title">Today's Transactions</div>
                                <div class="stat-icon">
                                    <i class="fas fa-exchange-alt"></i>
                                </div>
                            </div>
                            <div class="stat-value">BDT <?php echo number_format($stats['total_transactions_today'], 2); ?></div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i> 8.5% from yesterday
                            </div>
                        </div>
                        
                        <div class="stat-card loans">
                            <div class="stat-header">
                                <div class="stat-title">Pending Loans</div>
                                <div class="stat-icon">
                                    <i class="fas fa-hand-holding-usd"></i>
                                </div>
                            </div>
                            <div class="stat-value"><?php echo $stats['pending_loans']; ?></div>
                            <div class="stat-change negative">
                                <i class="fas fa-arrow-up"></i> 3 new applications
                            </div>
                        </div>
                        
                        <div class="stat-card accounts">
                            <div class="stat-header">
                                <div class="stat-title">Pending Registrations</div>
                                <div class="stat-icon">
                                    <i class="fas fa-user-plus"></i>
                                </div>
                            </div>
                            <div class="stat-value"><?php echo $stats['pending_registrations']; ?></div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-down"></i> 2 approved today
                            </div>
                        </div>
                        
                        <div class="stat-card alerts">
                            <div class="stat-header">
                                <div class="stat-title">Pending Tasks</div>
                                <div class="stat-icon">
                                    <i class="fas fa-tasks"></i>
                                </div>
                            </div>
                            <div class="stat-value"><?php echo $stats['pending_tasks']; ?></div>
                            <div class="stat-change negative">
                                <i class="fas fa-arrow-up"></i> 1 new task
                            </div>
                        </div>
                        
                        <div class="stat-card attendance">
                            <div class="stat-header">
                                <div class="stat-title">Open Tickets</div>
                                <div class="stat-icon">
                                    <i class="fas fa-headset"></i>
                                </div>
                            </div>
                            <div class="stat-value"><?php echo $stats['open_tickets']; ?></div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-down"></i> 2 resolved today
                            </div>
                        </div>
                    </div>

                    <!-- Charts & Upcoming Tasks -->
                    <div class="charts-row">
                        <div class="chart-container">
                            <div class="chart-header">
                                <div class="chart-title">Daily Transaction Trend</div>
                                <div class="chart-actions">
                                    <select id="chartPeriod">
                                        <option>Last 7 Days</option>
                                        <option>Last 30 Days</option>
                                        <option>This Month</option>
                                    </select>
                                </div>
                            </div>
                            <div class="chart-wrapper">
                                <canvas id="transactionChart"></canvas>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Upcoming Tasks</div>
                                <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="viewAllTasks()">View All</button>
                            </div>
                            <div class="card-content">
                                <?php foreach(array_slice($employee_tasks, 0, 3) as $task): ?>
                                <div class="mb-20">
                                    <div><strong><?php echo date('h:i A', strtotime($task['due_date'])); ?></strong> - <?php echo $task['title']; ?></div>
                                    <div style="font-size: 12px; color: var(--dark);">Priority: <?php echo ucfirst($task['priority']); ?> • Status: <?php echo ucfirst($task['status']); ?></div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity -->
                    <div class="table-container">
                        <div class="chart-header">
                            <div class="chart-title">Recent Transactions</div>
                            <button class="btn btn-primary" onclick="viewAllTransactions()">View All</button>
                        </div>
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_transactions as $transaction): ?>
                                    <tr>
                                        <td><?php echo $transaction['transaction_id']; ?></td>
                                        <td><?php echo $transaction['first_name'] . ' ' . $transaction['last_name']; ?></td>
                                        <td><?php echo ucfirst($transaction['type']); ?></td>
                                        <td>BDT <?php echo number_format($transaction['amount'], 2); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($transaction['transaction_date'])); ?></td>
                                        <td><span class="status status-<?php echo $transaction['status'] === 'completed' ? 'completed' : 'pending'; ?>"><?php echo ucfirst($transaction['status']); ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Registrations Section -->
                <div class="section" id="registrations">
                    <div class="section-header">
                        <div class="section-title">Pending Registrations</div>
                        <div class="section-actions">
                            <button class="btn btn-success" onclick="exportRegistrations()"><i class="fas fa-file-export"></i> Export</button>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Account Type</th>
                                        <th>Initial Deposit</th>
                                        <th>Applied Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pending_registrations as $registration): ?>
                                    <tr>
                                        <td>#REG-<?php echo str_pad($registration['id'], 4, '0', STR_PAD_LEFT); ?></td>
                                        <td><?php echo $registration['first_name'] . ' ' . $registration['last_name']; ?></td>
                                        <td><?php echo $registration['username']; ?></td>
                                        <td><?php echo $registration['email']; ?></td>
                                        <td><?php echo $registration['phone']; ?></td>
                                        <td><?php echo $registration['account_type_name']; ?></td>
                                        <td>BDT <?php echo number_format($registration['initial_deposit'], 2); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($registration['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-success" onclick="approveRegistration(<?php echo $registration['id']; ?>)">Approve</button>
                                            <button class="btn btn-danger" onclick="rejectRegistration(<?php echo $registration['id']; ?>)">Reject</button>
                                            <button class="btn btn-primary" onclick="viewRegistration(<?php echo $registration['id']; ?>)">Details</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Customers Section -->
                <div class="section" id="customers">
                    <div class="section-header">
                        <div class="section-title">Customer Management</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showCreateAccountModal()"><i class="fas fa-plus"></i> Add Account</button>
                            <button class="btn btn-success" onclick="exportCustomers()"><i class="fas fa-file-export"></i> Export</button>
                        </div>
                    </div>

                    <div class="form-container mb-20">
                        <div class="form-group">
                            <label class="form-label">Search Customers</label>
                            <div style="display: flex; gap: 10px;">
                                <input type="text" id="customerSearch" class="form-control" placeholder="Search by name, email, or phone">
                                <button class="btn btn-primary" onclick="searchCustomers()">Search</button>
                            </div>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Customer ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Accounts</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_customers as $customer): ?>
                                    <tr>
                                        <td>#CUS-<?php echo str_pad($customer['id'], 4, '0', STR_PAD_LEFT); ?></td>
                                        <td><?php echo $customer['first_name'] . ' ' . $customer['last_name']; ?></td>
                                        <td><?php echo $customer['email']; ?></td>
                                        <td><?php echo $customer['phone']; ?></td>
                                        <td><?php echo $customer['account_count']; ?></td>
                                        <td><span class="status status-<?php echo $customer['status']; ?>"><?php echo ucfirst($customer['status']); ?></span></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewCustomer(<?php echo $customer['id']; ?>)">View</button>
                                            <button class="btn btn-info" onclick="sendMessageToCustomer(<?php echo $customer['id']; ?>)">Message</button>
                                            <?php if($customer['status'] == 'active'): ?>
                                            <button class="btn btn-warning" onclick="updateCustomerStatus(<?php echo $customer['id']; ?>, 'inactive')">Deactivate</button>
                                            <?php else: ?>
                                            <button class="btn btn-success" onclick="updateCustomerStatus(<?php echo $customer['id']; ?>, 'active')">Activate</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Accounts Section -->
                <div class="section" id="accounts">
                    <div class="section-header">
                        <div class="section-title">Account Management</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showCreateAccountModal()"><i class="fas fa-plus"></i> Open Account</button>
                            <button class="btn btn-success" onclick="refreshData()"><i class="fas fa-sync-alt"></i> Refresh</button>
                        </div>
                    </div>

                    <div class="grid-3">
                        <?php
                        $savings_count = $pdo->query("SELECT COUNT(*) as count FROM accounts a JOIN account_types at ON a.account_type_id = at.id WHERE at.name LIKE '%savings%' AND a.status = 'active'")->fetch()['count'];
                        $current_count = $pdo->query("SELECT COUNT(*) as count FROM accounts a JOIN account_types at ON a.account_type_id = at.id WHERE at.name LIKE '%current%' AND a.status = 'active'")->fetch()['count'];
                        $fixed_count = $pdo->query("SELECT COUNT(*) as count FROM accounts a JOIN account_types at ON a.account_type_id = at.id WHERE at.name LIKE '%fixed%' AND a.status = 'active'")->fetch()['count'];
                        ?>
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Savings Accounts</div>
                            </div>
                            <div class="stat-value"><?php echo $savings_count; ?></div>
                            <div class="stat-title">Active Accounts</div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Current Accounts</div>
                            </div>
                            <div class="stat-value"><?php echo $current_count; ?></div>
                            <div class="stat-title">Active Accounts</div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Fixed Deposits</div>
                            </div>
                            <div class="stat-value"><?php echo $fixed_count; ?></div>
                            <div class="stat-title">Active Deposits</div>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Account No</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                        <th>Open Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_accounts as $account): ?>
                                    <tr>
                                        <td><?php echo $account['account_number']; ?></td>
                                        <td><?php echo $account['first_name'] . ' ' . $account['last_name']; ?></td>
                                        <td><?php echo $account['account_type']; ?></td>
                                        <td>BDT <?php echo number_format($account['balance'], 2); ?></td>
                                        <td><span class="status status-<?php echo $account['status']; ?>"><?php echo ucfirst($account['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($account['opened_date'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewAccount(<?php echo $account['id']; ?>)">View</button>
                                            <?php if($account['status'] == 'active'): ?>
                                            <button class="btn btn-danger" onclick="updateAccountStatus(<?php echo $account['id']; ?>, 'frozen')">Freeze</button>
                                            <?php elseif($account['status'] == 'frozen'): ?>
                                            <button class="btn btn-success" onclick="updateAccountStatus(<?php echo $account['id']; ?>, 'active')">Unfreeze</button>
                                            <?php endif; ?>
                                            <button class="btn btn-warning" onclick="closeAccount(<?php echo $account['id']; ?>)">Close</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Transactions Section -->
                <div class="section" id="transactions">
                    <div class="section-header">
                        <div class="section-title">Transaction Management</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showCreateTransactionModal()"><i class="fas fa-plus"></i> New Transaction</button>
                            <button class="btn btn-success" onclick="exportTransactions()"><i class="fas fa-file-export"></i> Export</button>
                        </div>
                    </div>
                    
                    <div class="grid-2">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Pending Large Transactions</div>
                            </div>
                            <div class="card-content">
                                <?php
                                $large_transactions = $pdo->query("
                                    SELECT t.*, a.account_number, u.first_name, u.last_name 
                                    FROM transactions t 
                                    JOIN accounts a ON t.account_id = a.id 
                                    JOIN users u ON a.user_id = u.id 
                                    WHERE t.amount > 100000 AND t.status = 'pending'
                                    ORDER BY t.amount DESC 
                                    LIMIT 2
                                ")->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach($large_transactions as $transaction):
                                ?>
                                <div class="mb-20">
                                    <div><strong>BDT <?php echo number_format($transaction['amount'], 2); ?></strong> - <?php echo ucfirst($transaction['type']); ?></div>
                                    <div style="font-size: 12px; color: var(--dark);"><?php echo $transaction['first_name'] . ' ' . $transaction['last_name']; ?> • <?php echo date('M j, Y g:i A', strtotime($transaction['created_at'])); ?></div>
                                    <div class="mt-20">
                                        <button class="btn btn-success" style="padding: 5px 10px; font-size: 12px;" onclick="approveTransaction(<?php echo $transaction['id']; ?>)">Approve</button>
                                        <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="rejectTransaction(<?php echo $transaction['id']; ?>)">Reject</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Fraud Detection Alerts</div>
                            </div>
                            <div class="card-content">
                                <div class="mb-20">
                                    <div><strong>Unusual Activity</strong> - Multiple Failed Logins</div>
                                    <div style="font-size: 12px; color: var(--dark);">Account #7231 • Today, 09:20 AM</div>
                                    <div class="mt-20">
                                        <button class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Investigate</button>
                                    </div>
                                </div>
                                <div>
                                    <div><strong>Suspicious Transfer</strong> - New Recipient</div>
                                    <div style="font-size: 12px; color: var(--dark);">Account #4880 • Today, 10:45 AM</div>
                                    <div class="mt-20">
                                        <button class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Investigate</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-container">
                        <h3>Transaction Filters</h3>
                        <form id="transactionFilters" method="GET">
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
                                <div class="form-group">
                                    <label class="form-label">Transaction Type</label>
                                    <select class="form-control" name="type">
                                        <option value="">All Types</option>
                                        <option value="deposit">Deposit</option>
                                        <option value="withdrawal">Withdrawal</option>
                                        <option value="transfer">Transfer</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Date From</label>
                                    <input type="date" class="form-control" name="date_from">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Date To</label>
                                    <input type="date" class="form-control" name="date_to">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Amount Range</label>
                                    <select class="form-control" name="amount_range">
                                        <option value="">Any Amount</option>
                                        <option value="0-10000">Up to BDT 10,000</option>
                                        <option value="10000-50000">BDT 10,000 - BDT 50,000</option>
                                        <option value="50000+">Over BDT 50,000</option>
                                    </select>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" style="margin-top: 15px;" onclick="applyTransactionFilters()">Apply Filters</button>
                        </form>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <th>Account</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Description</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_transactions as $transaction): ?>
                                    <tr>
                                        <td><?php echo $transaction['transaction_id']; ?></td>
                                        <td><?php echo $transaction['account_number']; ?></td>
                                        <td><?php echo ucfirst($transaction['type']); ?></td>
                                        <td>BDT <?php echo number_format($transaction['amount'], 2); ?></td>
                                        <td><?php echo $transaction['description']; ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($transaction['transaction_date'])); ?></td>
                                        <td><span class="status status-<?php echo $transaction['status']; ?>"><?php echo ucfirst($transaction['status']); ?></span></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewTransaction(<?php echo $transaction['id']; ?>)">View</button>
                                            <?php if($transaction['status'] == 'pending'): ?>
                                            <button class="btn btn-success" onclick="approveTransaction(<?php echo $transaction['id']; ?>)">Approve</button>
                                            <button class="btn btn-danger" onclick="rejectTransaction(<?php echo $transaction['id']; ?>)">Reject</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Deposits/Withdrawals Section -->
                <div class="section" id="deposits-withdrawals">
                    <div class="section-header">
                        <div class="section-title">Deposits & Withdrawals</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showDepositModal()"><i class="fas fa-plus"></i> Process Deposit</button>
                            <button class="btn btn-success" onclick="showWithdrawalModal()"><i class="fas fa-minus"></i> Process Withdrawal</button>
                            <button class="btn btn-info" onclick="showTransferModal()"><i class="fas fa-exchange-alt"></i> Process Transfer</button>
                        </div>
                    </div>

                    <div class="grid-3">
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Today's Deposits</div>
                            </div>
                            <div class="stat-value">
                                <?php
                                $today_deposits = $pdo->query("SELECT SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND type = 'deposit'")->fetch()['total'] ?? 0;
                                echo "BDT " . number_format($today_deposits, 2);
                                ?>
                            </div>
                            <div class="stat-title">Total Deposits</div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Today's Withdrawals</div>
                            </div>
                            <div class="stat-value">
                                <?php
                                $today_withdrawals = $pdo->query("SELECT SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND type = 'withdrawal'")->fetch()['total'] ?? 0;
                                echo "BDT " . number_format($today_withdrawals, 2);
                                ?>
                            </div>
                            <div class="stat-title">Total Withdrawals</div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Today's Transfers</div>
                            </div>
                            <div class="stat-value">
                                <?php
                                $today_transfers = $pdo->query("SELECT COUNT(*) as count FROM transactions WHERE DATE(created_at) = CURDATE() AND type = 'transfer'")->fetch()['count'] ?? 0;
                                echo $today_transfers;
                                ?>
                            </div>
                            <div class="stat-title">Total Transfers</div>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <th>Account</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Description</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $recent_deposits_withdrawals = $pdo->query("
                                        SELECT t.*, a.account_number, u.first_name, u.last_name 
                                        FROM transactions t 
                                        JOIN accounts a ON t.account_id = a.id 
                                        JOIN users u ON a.user_id = u.id 
                                        WHERE t.type IN ('deposit', 'withdrawal', 'transfer')
                                        ORDER BY t.created_at DESC 
                                        LIMIT 10
                                    ")->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($recent_deposits_withdrawals as $transaction): 
                                    ?>
                                    <tr>
                                        <td><?php echo $transaction['transaction_id']; ?></td>
                                        <td><?php echo $transaction['account_number']; ?></td>
                                        <td><?php echo ucfirst($transaction['type']); ?></td>
                                        <td>BDT <?php echo number_format($transaction['amount'], 2); ?></td>
                                        <td><?php echo $transaction['description']; ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($transaction['transaction_date'])); ?></td>
                                        <td><span class="status status-<?php echo $transaction['status']; ?>"><?php echo ucfirst($transaction['status']); ?></span></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewTransaction(<?php echo $transaction['id']; ?>)">View</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Loans Section - Enhanced with Payment Options -->
                <div class="section" id="loans">
                    <div class="section-header">
                        <div class="section-title">Loan Management</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showCreateLoanModal()"><i class="fas fa-plus"></i> New Loan</button>
                            <button class="btn btn-success" onclick="approveSelectedLoans()"><i class="fas fa-check"></i> Approve Selected</button>
                            <button class="btn btn-info" onclick="showLoanPaymentModal()"><i class="fas fa-money-bill-wave"></i> Process Payment</button>
                        </div>
                    </div>
                    
                    <div class="grid-2">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Loan Applications</div>
                            </div>
                            <div class="card-content">
                                <?php foreach(array_slice($pending_loans, 0, 2) as $loan): ?>
                                <div class="mb-20">
                                    <div><strong><?php echo ucfirst($loan['loan_type']); ?> Loan</strong> - BDT <?php echo number_format($loan['amount'], 2); ?></div>
                                    <div style="font-size: 12px; color: var(--dark);"><?php echo $loan['first_name'] . ' ' . $loan['last_name']; ?> • Applied: <?php echo date('M j, Y', strtotime($loan['applied_date'])); ?></div>
                                    <div class="mt-20">
                                        <button class="btn btn-success" style="padding: 5px 10px; font-size: 12px;" onclick="approveLoan(<?php echo $loan['id']; ?>)">Approve</button>
                                        <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="rejectLoan(<?php echo $loan['id']; ?>)">Reject</button>
                                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="viewLoan(<?php echo $loan['id']; ?>)">Details</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Active Loans Summary</div>
                            </div>
                            <div class="card-content">
                                <div class="mb-20">
                                    <div><strong>Total Active Loans:</strong> <?php echo $stats['active_loans']; ?></div>
                                </div>
                                <div class="mb-20">
                                    <div><strong>Total Loan Amount:</strong> BDT 
                                        <?php 
                                        $total_loan_amount = $pdo->query("SELECT SUM(amount) as total FROM loans WHERE status = 'active'")->fetch()['total'] ?? 0;
                                        echo number_format($total_loan_amount, 2);
                                        ?>
                                    </div>
                                </div>
                                <div>
                                    <div><strong>Total Outstanding:</strong> BDT 
                                        <?php 
                                        $total_outstanding = $pdo->query("SELECT SUM(remaining_balance) as total FROM loans WHERE status = 'active'")->fetch()['total'] ?? 0;
                                        echo number_format($total_outstanding, 2);
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="selectAllLoans"></th>
                                        <th>Loan Number</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Remaining</th>
                                        <th>Status</th>
                                        <th>Applied Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_loans as $loan): ?>
                                    <tr>
                                        <td><input type="checkbox" class="loan-checkbox" value="<?php echo $loan['id']; ?>"></td>
                                        <td><?php echo $loan['loan_number']; ?></td>
                                        <td><?php echo $loan['first_name'] . ' ' . $loan['last_name']; ?></td>
                                        <td><?php echo ucfirst($loan['loan_type']); ?></td>
                                        <td>BDT <?php echo number_format($loan['amount'], 2); ?></td>
                                        <td>BDT <?php echo number_format($loan['remaining_balance'], 2); ?></td>
                                        <td><span class="status status-<?php echo $loan['status']; ?>"><?php echo ucfirst($loan['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($loan['applied_date'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewLoan(<?php echo $loan['id']; ?>)">View</button>
                                            <?php if($loan['status'] == 'pending'): ?>
                                            <button class="btn btn-success" onclick="approveLoan(<?php echo $loan['id']; ?>)">Approve</button>
                                            <button class="btn btn-danger" onclick="rejectLoan(<?php echo $loan['id']; ?>)">Reject</button>
                                            <?php elseif($loan['status'] == 'approved'): ?>
                                            <button class="btn btn-info" onclick="activateLoan(<?php echo $loan['id']; ?>)">Activate</button>
                                            <?php elseif($loan['status'] == 'active'): ?>
                                            <button class="btn btn-warning" onclick="showLoanPaymentModal(<?php echo $loan['id']; ?>)">Payment</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Customer Care Section -->
                <div class="section" id="customer-care">
                    <div class="section-header">
                        <div class="section-title">Customer Care Tickets</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="refreshTickets()"><i class="fas fa-sync-alt"></i> Refresh</button>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Ticket #</th>
                                        <th>Customer</th>
                                        <th>Subject</th>
                                        <th>Priority</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($customer_tickets as $ticket): ?>
                                    <tr>
                                        <td><?php echo $ticket['ticket_number']; ?></td>
                                        <td><?php echo $ticket['first_name'] . ' ' . $ticket['last_name']; ?></td>
                                        <td><?php echo $ticket['subject']; ?></td>
                                        <td><span class="status status-<?php echo $ticket['priority']; ?>"><?php echo ucfirst($ticket['priority']); ?></span></td>
                                        <td><span class="status status-<?php echo $ticket['status'] == 'in progress' ? 'pending' : $ticket['status']; ?>"><?php echo ucfirst($ticket['status']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($ticket['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewTicket(<?php echo $ticket['id']; ?>)">View</button>
                                            <?php if($ticket['status'] == 'open'): ?>
                                            <button class="btn btn-success" onclick="assignTicket(<?php echo $ticket['id']; ?>)">Assign to Me</button>
                                            <?php elseif($ticket['status'] == 'in progress' && $ticket['assigned_to'] == $employee_id): ?>
                                            <button class="btn btn-info" onclick="respondToTicket(<?php echo $ticket['id']; ?>)">Respond</button>
                                            <button class="btn btn-success" onclick="closeTicket(<?php echo $ticket['id']; ?>)">Close</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Feedback Section -->
                <div class="section" id="feedback">
                    <div class="section-header">
                        <div class="section-title">Customer Feedback & Reviews</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="exportFeedback()"><i class="fas fa-download"></i> Export</button>
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Feedback Summary</div>
                            </div>
                            <div class="card-content">
                                <?php
                                $avg_rating = $pdo->query("SELECT AVG(rating) as avg_rating FROM feedback")->fetch()['avg_rating'] ?? 0;
                                $total_feedback = $pdo->query("SELECT COUNT(*) as count FROM feedback")->fetch()['count'];
                                ?>
                                <div class="mb-20">
                                    <div><strong>Average Rating:</strong> <?php echo number_format($avg_rating, 1); ?> / 5</div>
                                    <div style="font-size: 14px; color: var(--warning);">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <i class="fas fa-star<?php echo $i <= round($avg_rating) ? '' : '-o'; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <div>
                                    <div><strong>Total Feedback:</strong> <?php echo $total_feedback; ?></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Service Type Distribution</div>
                            </div>
                            <div class="card-content">
                                <?php
                                $service_types = $pdo->query("
                                    SELECT service_type, COUNT(*) as count 
                                    FROM feedback 
                                    GROUP BY service_type
                                ")->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach($service_types as $type):
                                ?>
                                <div class="mb-10">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span><?php echo ucfirst(str_replace('_', ' ', $type['service_type'])); ?></span>
                                        <span><?php echo $type['count']; ?></span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Rating</th>
                                        <th>Review</th>
                                        <th>Service Type</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($customer_feedback as $feedback): ?>
                                    <tr>
                                        <td><?php echo $feedback['first_name'] . ' ' . $feedback['last_name']; ?></td>
                                        <td>
                                            <div style="color: var(--warning);">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star<?php echo $i <= $feedback['rating'] ? '' : '-o'; ?>"></i>
                                                <?php endfor; ?>
                                            </div>
                                        </td>
                                        <td><?php echo substr($feedback['review'], 0, 100) . (strlen($feedback['review']) > 100 ? '...' : ''); ?></td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $feedback['service_type'])); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($feedback['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewFeedback(<?php echo $feedback['id']; ?>)">View</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Reports Section -->
                <div class="section" id="reports">
                    <div class="section-header">
                        <div class="section-title">Reports & Analytics</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="generateReport()"><i class="fas fa-download"></i> Download Report</button>
                            <button class="btn btn-success" onclick="showAnalytics()"><i class="fas fa-chart-line"></i> Generate Analytics</button>
                        </div>
                    </div>
                    
                    <div class="grid-3">
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Customer Report</div>
                            </div>
                            <div class="card-content">
                                <p>Generate customer activity and account reports</p>
                                <button class="btn btn-primary" onclick="generateCustomerReport()">Generate</button>
                            </div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Transaction Report</div>
                            </div>
                            <div class="card-content">
                                <p>Generate transaction history and analysis</p>
                                <button class="btn btn-primary" onclick="generateTransactionReport()">Generate</button>
                            </div>
                        </div>
                        
                        <div class="card text-center">
                            <div class="card-header">
                                <div class="card-title">Loan Report</div>
                            </div>
                            <div class="card-content">
                                <p>Generate loan portfolio and performance reports</p>
                                <button class="btn btn-primary" onclick="generateLoanReport()">Generate</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tasks Section -->
                <div class="section" id="tasks">
                    <div class="section-header">
                        <div class="section-title">Task Management</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showCreateTaskModal()"><i class="fas fa-plus"></i> New Task</button>
                            <button class="btn btn-success" onclick="markSelectedTasksComplete()"><i class="fas fa-check"></i> Mark Complete</button>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="selectAllTasks"></th>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Priority</th>
                                        <th>Due Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($employee_tasks as $task): ?>
                                    <tr>
                                        <td><input type="checkbox" class="task-checkbox" value="<?php echo $task['id']; ?>"></td>
                                        <td><?php echo $task['title']; ?></td>
                                        <td><?php echo $task['description']; ?></td>
                                        <td><span class="status status-<?php echo $task['priority']; ?>"><?php echo ucfirst($task['priority']); ?></span></td>
                                        <td><?php echo date('M j, Y', strtotime($task['due_date'])); ?></td>
                                        <td><span class="status status-<?php echo $task['status']; ?>"><?php echo ucfirst($task['status']); ?></span></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewTask(<?php echo $task['id']; ?>)">View</button>
                                            <?php if($task['status'] != 'completed'): ?>
                                            <button class="btn btn-success" onclick="updateTaskStatus(<?php echo $task['id']; ?>, 'completed')">Complete</button>
                                            <?php endif; ?>
                                            <button class="btn btn-danger" onclick="deleteTask(<?php echo $task['id']; ?>)">Delete</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Communication Section -->
                <div class="section" id="communication">
                    <div class="section-header">
                        <div class="section-title">Customer Messages</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="refreshMessages()"><i class="fas fa-sync-alt"></i> Refresh</button>
                        </div>
                    </div>
                    
                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Customer</th>
                                        <th>Message</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($customer_messages as $message): ?>
                                    <tr>
                                        <td><?php echo $message['first_name'] . ' ' . $message['last_name']; ?></td>
                                        <td><?php echo substr($message['message'], 0, 100) . (strlen($message['message']) > 100 ? '...' : ''); ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($message['created_at'])); ?></td>
                                        <td><span class="status status-<?php echo $message['status']; ?>"><?php echo ucfirst($message['status']); ?></span></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewCustomerMessage(<?php echo $message['id']; ?>)">View</button>
                                            <?php if($message['status'] == 'unread'): ?>
                                            <button class="btn btn-info" onclick="respondToCustomerMessage(<?php echo $message['id']; ?>)">Respond</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Employee Messaging Section -->
                <div class="section" id="employee-messages">
                    <div class="section-header">
                        <div class="section-title">Employee Messaging</div>
                        <div class="section-actions">
                            <button class="btn btn-primary" onclick="showSendMessageModal()"><i class="fas fa-plus"></i> New Message</button>
                            <button class="btn btn-success" onclick="refreshMessages()"><i class="fas fa-sync-alt"></i> Refresh</button>
                        </div>
                    </div>

                    <div class="grid-2">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Message Statistics</div>
                            </div>
                            <div class="card-content">
                                <div class="mb-20">
                                    <div><strong>Unread Messages:</strong> <?php echo $unread_messages_count; ?></div>
                                </div>
                                <div class="mb-20">
                                    <div><strong>Total Messages:</strong> <?php echo count($employee_messages); ?></div>
                                </div>
                                <div>
                                    <div><strong>Sent Today:</strong> 
                                        <?php 
                                        $sent_today = $pdo->query("SELECT COUNT(*) as count FROM employee_messages WHERE sender_id = $employee_id AND DATE(created_at) = CURDATE()")->fetch()['count'];
                                        echo $sent_today;
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Quick Actions</div>
                            </div>
                            <div class="card-content">
                                <button class="btn btn-primary mb-10" style="width: 100%;" onclick="showSendMessageModal()">
                                    <i class="fas fa-envelope"></i> Compose New Message
                                </button>
                                <button class="btn btn-info mb-10" style="width: 100%;" onclick="markAllAsRead()">
                                    <i class="fas fa-check-double"></i> Mark All as Read
                                </button>
                                <button class="btn btn-warning" style="width: 100%;" onclick="exportMessages()">
                                    <i class="fas fa-download"></i> Export Messages
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="table-container">
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>From</th>
                                        <th>To</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($employee_messages as $message): ?>
                                    <tr>
                                        <td>
                                            <?php if($message['status'] == 'unread' && $message['recipient_id'] == $employee_id): ?>
                                                <span class="status status-pending">Unread</span>
                                            <?php else: ?>
                                                <span class="status status-completed">Read</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $message['sender_first_name'] . ' ' . $message['sender_last_name']; ?></td>
                                        <td><?php echo $message['recipient_first_name'] . ' ' . $message['recipient_last_name']; ?></td>
                                        <td><?php echo $message['subject']; ?></td>
                                        <td><?php echo substr($message['message'], 0, 50) . (strlen($message['message']) > 50 ? '...' : ''); ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($message['created_at'])); ?></td>
                                        <td>
                                            <button class="btn btn-primary" onclick="viewEmployeeMessage(<?php echo $message['id']; ?>)">View</button>
                                            <?php if($message['status'] == 'unread' && $message['recipient_id'] == $employee_id): ?>
                                                <button class="btn btn-success" onclick="markMessageAsRead(<?php echo $message['id']; ?>)">Mark Read</button>
                                            <?php endif; ?>
                                            <button class="btn btn-danger" onclick="deleteEmployeeMessage(<?php echo $message['id']; ?>)">Delete</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Profile Section - Enhanced with Profile Picture -->
                <div class="section" id="profile">
                    <div class="section-header">
                        <div class="section-title">Profile & Settings</div>
                    </div>
                    
                    <div class="grid-2">
                        <div class="form-container">
                            <h3>Profile Information</h3>
                            <form id="profileForm" method="POST">
                                <input type="hidden" name="action" value="update_profile">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                    <div class="form-group">
                                        <label class="form-label">First Name</label>
                                        <input type="text" class="form-control" name="first_name" value="<?php echo $_SESSION['first_name']; ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Last Name</label>
                                        <input type="text" class="form-control" name="last_name" value="<?php echo $_SESSION['last_name']; ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo $_SESSION['email']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone</label>
                                    <input type="text" class="form-control" name="phone" value="<?php echo $_SESSION['phone'] ?? ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-control" name="address" rows="3"><?php echo $_SESSION['address'] ?? ''; ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Update Profile</button>
                            </form>
                        </div>
                        
                        <div class="form-container">
                            <h3>Profile Picture</h3>
                            <div style="text-align: center; margin-bottom: 20px;">
                                <div class="employee-avatar" style="width: 120px; height: 120px; margin: 0 auto 20px; background-image: url('<?php echo $_SESSION['profile_picture'] ?? ''; ?>');">
                                    <?php if(empty($_SESSION['profile_picture'])): ?>
                                        <?php echo substr($_SESSION['first_name'], 0, 1) . substr($_SESSION['last_name'], 0, 1); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <form id="profilePictureForm" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="upload_profile_picture">
                                <div class="form-group">
                                    <label class="form-label">Upload New Picture</label>
                                    <input type="file" class="form-control" name="profile_picture" accept="image/jpeg,image/jpg,image/png,image/gif">
                                    <small style="color: var(--dark);">Max file size: 5MB. Allowed formats: JPG, PNG, GIF</small>
                                </div>
                                <button type="submit" class="btn btn-primary">Upload Picture</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Security Section -->
                <div class="section" id="security">
                    <div class="section-header">
                        <div class="section-title">Security Settings</div>
                    </div>
                    
                    <div class="form-container">
                        <form id="securityForm" method="POST">
                            <input type="hidden" name="action" value="update_security">
                            <div class="form-group">
                                <label class="form-label">Current Password</label>
                                <input type="password" class="form-control" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">New Password</label>
                                <input type="password" class="form-control" name="new_password" required minlength="6">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" name="confirm_password" required minlength="6">
                            </div>
                            <button type="submit" class="btn btn-primary">Update Password</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- All existing modals from the enhanced version -->
    <!-- Rejection Modal -->
    <div class="modal" id="rejectModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reject Registration</h3>
                <button class="close-modal" onclick="closeModal('rejectModal')">&times;</button>
            </div>
            <form id="rejectForm" method="POST">
                <input type="hidden" name="action" value="reject_registration">
                <input type="hidden" name="registration_id" id="rejectRegistrationId">
                <div class="form-group">
                    <label for="rejectionReason">Reason for Rejection</label>
                    <textarea id="rejectionReason" name="reason" class="form-control" rows="4" required placeholder="Please provide a reason for rejection..."></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('rejectModal')">Cancel</button>
                    <button type="submit" class="btn btn-danger">Confirm Rejection</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Account Modal -->
    <div class="modal" id="createAccountModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create New Account</h3>
                <button class="close-modal" onclick="closeModal('createAccountModal')">&times;</button>
            </div>
            <form id="createAccountForm" method="POST">
                <input type="hidden" name="action" value="create_account">
                <div class="form-group">
                    <label class="form-label">Customer</label>
                    <select class="form-control" name="user_id" required>
                        <option value="">Select Customer</option>
                        <?php foreach($all_customers as $customer): ?>
                        <option value="<?php echo $customer['id']; ?>"><?php echo $customer['first_name'] . ' ' . $customer['last_name']; ?> (<?php echo $customer['email']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Account Type</label>
                    <select class="form-control" name="account_type" required>
                        <option value="">Select Account Type</option>
                        <?php foreach($account_types as $type): ?>
                        <option value="<?php echo $type['id']; ?>"><?php echo $type['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Branch</label>
                    <select class="form-control" name="branch_id" required>
                        <option value="">Select Branch</option>
                        <?php foreach($branches as $branch): ?>
                        <option value="<?php echo $branch['id']; ?>"><?php echo $branch['name']; ?> (<?php echo $branch['city']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Initial Deposit (BDT)</label>
                    <input type="number" class="form-control" name="initial_deposit" min="0" step="0.01" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('createAccountModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Transaction Modal -->
    <div class="modal" id="createTransactionModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create New Transaction</h3>
                <button class="close-modal" onclick="closeModal('createTransactionModal')">&times;</button>
            </div>
            <form id="createTransactionForm" method="POST">
                <input type="hidden" name="action" value="create_transaction">
                <div class="form-group">
                    <label class="form-label">Account</label>
                    <select class="form-control" name="account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach($all_accounts as $account): ?>
                        <option value="<?php echo $account['id']; ?>"><?php echo $account['account_number']; ?> - <?php echo $account['first_name'] . ' ' . $account['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Transaction Type</label>
                    <select class="form-control" name="type" required>
                        <option value="">Select Type</option>
                        <option value="deposit">Deposit</option>
                        <option value="withdrawal">Withdrawal</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('createTransactionModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Transaction</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Loan Modal -->
    <div class="modal" id="createLoanModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create New Loan</h3>
                <button class="close-modal" onclick="closeModal('createLoanModal')">&times;</button>
            </div>
            <form id="createLoanForm" method="POST">
                <input type="hidden" name="action" value="create_loan">
                <div class="form-group">
                    <label class="form-label">Customer</label>
                    <select class="form-control" name="user_id" required>
                        <option value="">Select Customer</option>
                        <?php foreach($all_customers as $customer): ?>
                        <option value="<?php echo $customer['id']; ?>"><?php echo $customer['first_name'] . ' ' . $customer['last_name']; ?> (<?php echo $customer['email']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Loan Type</label>
                    <select class="form-control" name="loan_type" required>
                        <option value="">Select Loan Type</option>
                        <option value="home">Home Loan</option>
                        <option value="car">Car Loan</option>
                        <option value="personal">Personal Loan</option>
                        <option value="business">Business Loan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Loan Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Interest Rate (%)</label>
                    <input type="number" class="form-control" name="interest_rate" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Loan Term (Months)</label>
                    <input type="number" class="form-control" name="term_months" min="1" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('createLoanModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Loan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Create Task Modal -->
    <div class="modal" id="createTaskModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create New Task</h3>
                <button class="close-modal" onclick="closeModal('createTaskModal')">&times;</button>
            </div>
            <form id="createTaskForm" method="POST">
                <input type="hidden" name="action" value="create_task">
                <div class="form-group">
                    <label class="form-label">Title</label>
                    <input type="text" class="form-control" name="title" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Assign To</label>
                    <select class="form-control" name="assigned_to" required>
                        <option value="">Select Employee</option>
                        <?php foreach($all_employees as $employee): ?>
                        <option value="<?php echo $employee['id']; ?>"><?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Priority</label>
                    <select class="form-control" name="priority" required>
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Due Date</label>
                    <input type="date" class="form-control" name="due_date" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('createTaskModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Task</button>
                </div>
            </form>
        </div>
    </div>

    <!-- New Modals for Enhanced Features -->
    
    <!-- Deposit Modal -->
    <div class="modal" id="depositModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Process Deposit</h3>
                <button class="close-modal" onclick="closeModal('depositModal')">&times;</button>
            </div>
            <form id="depositForm" method="POST">
                <input type="hidden" name="action" value="process_deposit">
                <div class="form-group">
                    <label class="form-label">Account</label>
                    <select class="form-control" name="account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach($all_accounts as $account): ?>
                        <option value="<?php echo $account['id']; ?>"><?php echo $account['account_number']; ?> - <?php echo $account['first_name'] . ' ' . $account['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('depositModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Process Deposit</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Withdrawal Modal -->
    <div class="modal" id="withdrawalModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Process Withdrawal</h3>
                <button class="close-modal" onclick="closeModal('withdrawalModal')">&times;</button>
            </div>
            <form id="withdrawalForm" method="POST">
                <input type="hidden" name="action" value="process_withdrawal">
                <div class="form-group">
                    <label class="form-label">Account</label>
                    <select class="form-control" name="account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach($all_accounts as $account): ?>
                        <option value="<?php echo $account['id']; ?>"><?php echo $account['account_number']; ?> - <?php echo $account['first_name'] . ' ' . $account['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('withdrawalModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Process Withdrawal</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Transfer Modal -->
    <div class="modal" id="transferModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Process Transfer</h3>
                <button class="close-modal" onclick="closeModal('transferModal')">&times;</button>
            </div>
            <form id="transferForm" method="POST">
                <input type="hidden" name="action" value="process_transfer">
                <div class="form-group">
                    <label class="form-label">From Account</label>
                    <select class="form-control" name="from_account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach($all_accounts as $account): ?>
                        <option value="<?php echo $account['id']; ?>"><?php echo $account['account_number']; ?> - <?php echo $account['first_name'] . ' ' . $account['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">To Account</label>
                    <select class="form-control" name="to_account_id" required>
                        <option value="">Select Account</option>
                        <?php foreach($all_accounts as $account): ?>
                        <option value="<?php echo $account['id']; ?>"><?php echo $account['account_number']; ?> - <?php echo $account['first_name'] . ' ' . $account['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('transferModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Process Transfer</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Loan Payment Modal -->
    <div class="modal" id="loanPaymentModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Process Loan Payment</h3>
                <button class="close-modal" onclick="closeModal('loanPaymentModal')">&times;</button>
            </div>
            <form id="loanPaymentForm" method="POST">
                <input type="hidden" name="action" value="make_loan_payment">
                <div class="form-group">
                    <label class="form-label">Loan</label>
                    <select class="form-control" name="loan_id" id="loanPaymentSelect" required>
                        <option value="">Select Loan</option>
                        <?php foreach($active_loans as $loan): ?>
                        <option value="<?php echo $loan['id']; ?>" data-balance="<?php echo $loan['remaining_balance']; ?>">
                            <?php echo $loan['loan_number']; ?> - <?php echo $loan['first_name'] . ' ' . $loan['last_name']; ?> (BDT <?php echo number_format($loan['remaining_balance'], 2); ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Remaining Balance</label>
                    <input type="text" class="form-control" id="remainingBalance" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Payment Amount (BDT)</label>
                    <input type="number" class="form-control" name="amount" min="0" step="0.01" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('loanPaymentModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Process Payment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Ticket Response Modal -->
    <div class="modal" id="ticketResponseModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Respond to Ticket</h3>
                <button class="close-modal" onclick="closeModal('ticketResponseModal')">&times;</button>
            </div>
            <form id="ticketResponseForm" method="POST">
                <input type="hidden" name="action" value="respond_to_ticket">
                <input type="hidden" name="ticket_id" id="responseTicketId">
                <div class="form-group">
                    <label class="form-label">Response</label>
                    <textarea class="form-control" name="response" rows="6" required placeholder="Enter your response to the customer..."></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('ticketResponseModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Response</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Customer Message Response Modal -->
    <div class="modal" id="customerMessageModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Respond to Customer Message</h3>
                <button class="close-modal" onclick="closeModal('customerMessageModal')">&times;</button>
            </div>
            <form id="customerMessageForm" method="POST">
                <input type="hidden" name="action" value="send_customer_message">
                <input type="hidden" name="customer_id" id="messageCustomerId">
                <div class="form-group">
                    <label class="form-label">Customer</label>
                    <input type="text" class="form-control" id="messageCustomerName" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Your Response</label>
                    <textarea class="form-control" name="message" rows="6" required placeholder="Enter your response to the customer..."></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('customerMessageModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Response</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Send Employee Message Modal -->
    <div class="modal" id="sendMessageModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Send Message to Employee</h3>
                <button class="close-modal" onclick="closeModal('sendMessageModal')">&times;</button>
            </div>
            <form id="sendMessageForm" method="POST">
                <input type="hidden" name="action" value="send_employee_message">
                <div class="form-group">
                    <label class="form-label">Recipient</label>
                    <select class="form-control" name="recipient_id" required>
                        <option value="">Select Employee</option>
                        <?php foreach($all_employees as $employee): ?>
                        <option value="<?php echo $employee['id']; ?>"><?php echo $employee['first_name'] . ' ' . $employee['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Subject</label>
                    <input type="text" class="form-control" name="subject" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Message</label>
                    <textarea class="form-control" name="message" rows="6" required placeholder="Type your message here..."></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeModal('sendMessageModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // JavaScript for all interactive functionality
        
        
        
        
        // Theme Toggle
        const themeToggle = document.getElementById('themeToggle');
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            const icon = themeToggle.querySelector('i');
            if (document.body.classList.contains('dark-mode')) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
            }
        });

        // Mobile Menu Toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });

        // Section Navigation
        const menuLinks = document.querySelectorAll('.menu-link');
        const sections = document.querySelectorAll('.section');
        const pageTitle = document.getElementById('pageTitle');

        menuLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get the target section
                const targetSection = this.getAttribute('data-section');
                
                // Update active menu item
                menuLinks.forEach(item => item.classList.remove('active'));
                this.classList.add('active');
                
                // Show target section
                sections.forEach(section => {
                    section.classList.remove('active');
                    if (section.id === targetSection) {
                        section.classList.add('active');
                    }
                });
                
                // Update page title
                const menuText = this.querySelector('span').textContent;
                pageTitle.textContent = menuText + " - Employee Dashboard";
                
                // Close sidebar on mobile after selection
                if (window.innerWidth <= 1200) {
                    sidebar.classList.remove('active');
                }
            });
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 1200 && 
                !sidebar.contains(e.target) && 
                !mobileMenuToggle.contains(e.target) && 
                sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Add interactivity to buttons
        document.addEventListener('DOMContentLoaded', function() {
            const buttons = document.querySelectorAll('.btn');
            buttons.forEach(button => {
                button.addEventListener('click', function() {
                    // Add a small animation to buttons when clicked
                    this.style.transform = 'scale(0.95)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 150);
                });
            });
        });

        // New Functions for Enhanced Features
        
        // Deposit/Withdrawal/Transfer Modals
        function showDepositModal() {
            document.getElementById('depositModal').style.display = 'flex';
        }
        
        function showWithdrawalModal() {
            document.getElementById('withdrawalModal').style.display = 'flex';
        }
        
        function showTransferModal() {
            document.getElementById('transferModal').style.display = 'flex';
        }
        
        // Loan Payment Modal
        function showLoanPaymentModal(loanId = null) {
            if (loanId) {
                document.getElementById('loanPaymentSelect').value = loanId;
                updateRemainingBalance();
            }
            document.getElementById('loanPaymentModal').style.display = 'flex';
        }
        
        function updateRemainingBalance() {
            const select = document.getElementById('loanPaymentSelect');
            const selectedOption = select.options[select.selectedIndex];
            const balance = selectedOption.getAttribute('data-balance');
            document.getElementById('remainingBalance').value = 'BDT ' + parseFloat(balance).toFixed(2);
        }
        
        // Ticket Functions
        function assignTicket(ticketId) {
            if (confirm('Are you sure you want to assign this ticket to yourself?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_ticket_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'ticket_id';
                idInput.value = ticketId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'in progress';
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function respondToTicket(ticketId) {
            document.getElementById('responseTicketId').value = ticketId;
            document.getElementById('ticketResponseModal').style.display = 'flex';
        }
        
        function closeTicket(ticketId) {
            if (confirm('Are you sure you want to close this ticket?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_ticket_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'ticket_id';
                idInput.value = ticketId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'closed';
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Customer Message Functions
        function respondToCustomerMessage(messageId) {
            // Get customer details from the message
            const messageRow = document.querySelector(`tr:has(button[onclick="viewCustomerMessage(${messageId})"])`);
            const customerName = messageRow.cells[0].textContent;
            const customerId = messageRow.querySelector('button[onclick^="respondToCustomerMessage"]').getAttribute('onclick').match(/\d+/)[0];
            
            document.getElementById('messageCustomerId').value = customerId;
            document.getElementById('messageCustomerName').value = customerName;
            document.getElementById('customerMessageModal').style.display = 'flex';
        }
        
        function sendMessageToCustomer(customerId) {
            const customerRow = document.querySelector(`tr:has(button[onclick="sendMessageToCustomer(${customerId})"])`);
            const customerName = customerRow.cells[1].textContent;
            
            document.getElementById('messageCustomerId').value = customerId;
            document.getElementById('messageCustomerName').value = customerName;
            document.getElementById('customerMessageModal').style.display = 'flex';
        }
        
        // Employee Messaging Functions
        function showSendMessageModal() {
            document.getElementById('sendMessageModal').style.display = 'flex';
        }

        function markMessageAsRead(messageId) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'mark_message_read';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'message_id';
            idInput.value = messageId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }

        function markAllAsRead() {
            if (confirm('Are you sure you want to mark all messages as read?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'mark_all_messages_read';
                form.appendChild(actionInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }

        function viewEmployeeMessage(messageId) {
            alert('Viewing message ID: ' + messageId + '. In a real implementation, this would show the full message.');
            // Mark as read when viewing
            markMessageAsRead(messageId);
        }

        function deleteEmployeeMessage(messageId) {
            if (confirm('Are you sure you want to delete this message?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_employee_message';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'message_id';
                idInput.value = messageId;
                form.appendChild(idInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }

        function exportMessages() {
            alert('Exporting messages... This would generate a file in a real application.');
            window.open('export_reports.php?type=messages', '_blank');
        }
        
        // Loan Activation
        function activateLoan(loanId) {
            if (confirm('Are you sure you want to activate this loan? This will make it active for payments.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'activate_loan';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'loan_id';
                idInput.value = loanId;
                form.appendChild(idInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Refresh Functions
        function refreshTickets() {
            location.reload();
        }
        
        function refreshMessages() {
            location.reload();
        }
        
        // Export Feedback
        function exportFeedback() {
            alert('Exporting feedback... This would generate a PDF/Excel file in a real application.');
            window.open('export_reports.php?type=feedback', '_blank');
        }
        
        // View Functions (placeholder implementations)
        function viewTicket(ticketId) {
            alert('Viewing ticket ID: ' + ticketId + '. In a real implementation, this would show ticket details.');
        }
        
        function viewFeedback(feedbackId) {
            alert('Viewing feedback ID: ' + feedbackId + '. In a real implementation, this would show full feedback details.');
        }
        
        function viewCustomerMessage(messageId) {
            alert('Viewing customer message ID: ' + messageId + '. In a real implementation, this would show full message details.');
        }
        
        // All existing JavaScript functions from the original code
        
        // Registration Functions
        function approveRegistration(registrationId) {
            if (confirm('Are you sure you want to approve this registration?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'approve_registration';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'registration_id';
                idInput.value = registrationId;
                form.appendChild(idInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function rejectRegistration(registrationId) {
            document.getElementById('rejectRegistrationId').value = registrationId;
            document.getElementById('rejectModal').style.display = 'flex';
        }
        
        // Loan Functions
        function approveLoan(loanId) {
            if (confirm('Are you sure you want to approve this loan?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_loan_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'loan_id';
                idInput.value = loanId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'approved';
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function rejectLoan(loanId) {
            if (confirm('Are you sure you want to reject this loan?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_loan_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'loan_id';
                idInput.value = loanId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'rejected';
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function approveSelectedLoans() {
            const selectedLoans = Array.from(document.querySelectorAll('.loan-checkbox:checked')).map(cb => cb.value);
            if (selectedLoans.length === 0) {
                alert('Please select at least one loan to approve.');
                return;
            }
            
            if (confirm(`Are you sure you want to approve ${selectedLoans.length} selected loans?`)) {
                selectedLoans.forEach(loanId => {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '';
                    
                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'update_loan_status';
                    form.appendChild(actionInput);
                    
                    const idInput = document.createElement('input');
                    idInput.type = 'hidden';
                    idInput.name = 'loan_id';
                    idInput.value = loanId;
                    form.appendChild(idInput);
                    
                    const statusInput = document.createElement('input');
                    statusInput.type = 'hidden';
                    statusInput.name = 'status';
                    statusInput.value = 'approved';
                    form.appendChild(statusInput);
                    
                    document.body.appendChild(form);
                    form.submit();
                });
            }
        }
        
        // Account Functions
        function updateAccountStatus(accountId, status) {
            if (confirm(`Are you sure you want to ${status} this account?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_account_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'account_id';
                idInput.value = accountId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = status;
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function closeAccount(accountId) {
            if (confirm('Are you sure you want to close this account? This action cannot be undone.')) {
                updateAccountStatus(accountId, 'closed');
            }
        }
        
        // Customer Functions
        function updateCustomerStatus(customerId, status) {
            if (confirm(`Are you sure you want to ${status} this customer?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_customer_status';
                form.appendChild(actionInput);
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'customer_id';
                idInput.value = customerId;
                form.appendChild(idInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = status;
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Transaction Functions
        function approveTransaction(transactionId) {
            if (confirm('Are you sure you want to approve this transaction?')) {
                // In a real implementation, this would update the transaction status
                alert('Transaction approved! In a real implementation, this would update the database.');
            }
        }
        
        function rejectTransaction(transactionId) {
            if (confirm('Are you sure you want to reject this transaction?')) {
                // In a real implementation, this would update the transaction status
                alert('Transaction rejected! In a real implementation, this would update the database.');
            }
        }
        
        // Task Functions
        function updateTaskStatus(taskId, status) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'update_task_status';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'task_id';
            idInput.value = taskId;
            form.appendChild(idInput);
            
            const statusInput = document.createElement('input');
            statusInput.type = 'hidden';
            statusInput.name = 'status';
            statusInput.value = status;
            form.appendChild(statusInput);
            
            document.body.appendChild(form);
            form.submit();
        }
        
        function markSelectedTasksComplete() {
            const selectedTasks = Array.from(document.querySelectorAll('.task-checkbox:checked')).map(cb => cb.value);
            if (selectedTasks.length === 0) {
                alert('Please select at least one task to mark as complete.');
                return;
            }
            
            if (confirm(`Are you sure you want to mark ${selectedTasks.length} selected tasks as complete?`)) {
                selectedTasks.forEach(taskId => {
                    updateTaskStatus(taskId, 'completed');
                });
            }
        }
        
        function deleteTask(taskId) {
            if (confirm('Are you sure you want to delete this task?')) {
                // In a real implementation, this would delete the task from the database
                alert('Task deleted! In a real implementation, this would remove it from the database.');
            }
        }
        
        // Modal Functions
        function showCreateAccountModal() {
            document.getElementById('createAccountModal').style.display = 'flex';
        }
        
        function showCreateTransactionModal() {
            document.getElementById('createTransactionModal').style.display = 'flex';
        }
        
        function showCreateLoanModal() {
            document.getElementById('createLoanModal').style.display = 'flex';
        }
        
        function showCreateTaskModal() {
            document.getElementById('createTaskModal').style.display = 'flex';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
        
        // Utility Functions
        function refreshData() {
            location.reload();
        }
        
        function exportReport() {
            alert('Exporting report... This would generate a PDF/Excel file in a real application.');
            // In real implementation, this would redirect to an export script
            window.open('export_reports.php?type=dashboard', '_blank');
        }
        
        function exportRegistrations() {
            window.open('export_reports.php?type=registrations', '_blank');
        }
        
        function exportCustomers() {
            window.open('export_reports.php?type=customers', '_blank');
        }
        
        function exportTransactions() {
            window.open('export_reports.php?type=transactions', '_blank');
        }
        
        function exportDeposits() {
            window.open('export_reports.php?type=deposits', '_blank');
        }
        
        function viewAllTransactions() {
            // Navigate to transactions section
            document.querySelector('.menu-link[data-section="transactions"]').click();
        }
        
        function viewAllTasks() {
            // Navigate to tasks section
            document.querySelector('.menu-link[data-section="tasks"]').click();
        }
        
        // EMI Calculator
        function calculateEMI() {
            const amount = parseFloat(document.getElementById('loanAmount').value);
            const rate = parseFloat(document.getElementById('interestRate').value);
            const term = parseInt(document.getElementById('loanTerm').value) * 12; // Convert years to months
            
            if (isNaN(amount) || isNaN(rate) || isNaN(term)) {
                alert('Please enter valid numbers for all fields.');
                return;
            }
            
            const monthlyRate = rate / 100 / 12;
            const emi = (amount * monthlyRate * Math.pow(1 + monthlyRate, term)) / (Math.pow(1 + monthlyRate, term) - 1);
            const totalPayment = emi * term;
            const totalInterest = totalPayment - amount;
            
            document.getElementById('emiResult').innerHTML = `
                <div><strong>Monthly EMI:</strong> BDT ${emi.toFixed(2)}</div>
                <div><strong>Total Interest:</strong> BDT ${totalInterest.toFixed(2)}</div>
                <div><strong>Total Payment:</strong> BDT ${totalPayment.toFixed(2)}</div>
            `;
        }
        
        // Select all loans checkbox
        document.getElementById('selectAllLoans').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.loan-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });
        
        // Select all tasks checkbox
        document.getElementById('selectAllTasks').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.task-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
        });
        
        // Search customers
        function searchCustomers() {
            const searchTerm = document.getElementById('customerSearch').value.toLowerCase();
            const rows = document.querySelectorAll('#customers table tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Apply transaction filters
        function applyTransactionFilters() {
            alert('Filters applied! In a real implementation, this would filter the transaction table.');
        }
        
        // Send message
        function sendMessage() {
            const recipient = document.getElementById('messageRecipient').value;
            const subject = document.getElementById('messageSubject').value;
            const content = document.getElementById('messageContent').value;
            
            if (!recipient || !subject || !content) {
                alert('Please fill in all fields.');
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'send_message';
            form.appendChild(actionInput);
            
            const recipientInput = document.createElement('input');
            recipientInput.type = 'hidden';
            recipientInput.name = 'recipient_id';
            recipientInput.value = recipient;
            form.appendChild(recipientInput);
            
            const subjectInput = document.createElement('input');
            subjectInput.type = 'hidden';
            subjectInput.name = 'subject';
            subjectInput.value = subject;
            form.appendChild(subjectInput);
            
            const messageInput = document.createElement('input');
            messageInput.type = 'hidden';
            messageInput.name = 'message';
            messageInput.value = content;
            form.appendChild(messageInput);
            
            document.body.appendChild(form);
            form.submit();
        }
        
        // Report generation functions
        function generateCustomerReport() {
            alert('Generating customer report... This would create a PDF/Excel file in a real application.');
        }
        
        function generateTransactionReport() {
            alert('Generating transaction report... This would create a PDF/Excel file in a real application.');
        }
        
        function generateLoanReport() {
            alert('Generating loan report... This would create a PDF/Excel file in a real application.');
        }
        
        // Charts
        document.addEventListener('DOMContentLoaded', function() {
            // Transaction Chart
            const transactionCtx = document.getElementById('transactionChart').getContext('2d');
            const transactionChart = new Chart(transactionCtx, {
                type: 'line',
                data: {
                    labels: ['9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM'],
                    datasets: [{
                        label: 'Deposits',
                        data: [45000, 52000, 48000, 61000, 55000, 72000, 68000],
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        tension: 0.3,
                        fill: true
                    }, {
                        label: 'Withdrawals',
                        data: [38000, 42000, 35000, 48000, 52000, 45000, 39000],
                        borderColor: '#e74c3c',
                        backgroundColor: 'rgba(231, 76, 60, 0.1)',
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'BDT' + value/1000 + 'k';
                                }
                            }
                        }
                    }
                }
            });
            
            // Update remaining balance when loan selection changes
            document.getElementById('loanPaymentSelect').addEventListener('change', updateRemainingBalance);
        });
    </script>
</body>
</html>