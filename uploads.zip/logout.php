<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Logout | Losers Bank</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a6c, #2a3c7f, #3d52a0);
            color: #fff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 800px;
            width: 90%;
            text-align: center;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .logo {
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .logo i {
            font-size: 2.5rem;
            color: #4CAF50;
        }
        
        .logo h1 {
            font-size: 2.2rem;
            font-weight: 700;
            letter-spacing: 1px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .logout-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 15px;
            padding: 2.5rem;
            margin: 1.5rem 0;
            position: relative;
            overflow: hidden;
        }
        
        .icon-container {
            margin: 1.5rem auto;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .icon-container i {
            font-size: 3.5rem;
            color: #4CAF50;
        }
        
        .message {
            margin: 1.5rem 0;
        }
        
        .message h2 {
            font-size: 1.8rem;
            margin-bottom: 1rem;
            color: #4CAF50;
        }
        
        .message p {
            font-size: 1.2rem;
            line-height: 1.6;
            opacity: 0.9;
        }
        
        .reason {
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 10px;
            margin: 1.5rem 0;
            display: none;
        }
        
        .reason.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        .reason i {
            margin-right: 10px;
            color: #FFC107;
        }
        
        .buttons {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 0.8rem 1.8rem;
            border: none;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        
        .btn-login {
            background: #4CAF50;
            color: white;
            box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
        }
        
        .btn-home {
            background: transparent;
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }
        
        .btn-login:hover {
            background: #45a049;
        }
        
        .btn-home:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .security-info {
            margin-top: 2rem;
            padding: 1rem;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .security-info i {
            color: #4CAF50;
            margin-right: 5px;
        }
        
        .animation-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }
        
        .floating-card {
            position: absolute;
            width: 60px;
            height: 40px;
            background: linear-gradient(45deg, #FFD700, #FFA500);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            opacity: 0;
        }
        
        .lock {
            position: absolute;
            font-size: 2rem;
            color: #4CAF50;
            opacity: 0;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
            100% { transform: translateY(0) rotate(0deg); }
        }
        
        @media (max-width: 600px) {
            .container {
                padding: 1.5rem;
            }
            
            .logo h1 {
                font-size: 1.8rem;
            }
            
            .logout-card {
                padding: 1.5rem;
            }
            
            .buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .btn {
                width: 100%;
                max-width: 250px;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>LOSERS BANK</h1>
        </div>
        
        <div class="logout-card">
            <div class="animation-container" id="animationContainer"></div>
            
            <div class="icon-container">
                <i class="fas fa-lock" id="lockIcon"></i>
            </div>
            
            <div class="message">
                <h2 id="logoutTitle">You have been securely logged out</h2>
                <p>Thank you for banking with Losers Bank. Your security is our priority.</p>
            </div>
            
            <div class="reason" id="reasonBox">
                <i class="fas fa-exclamation-triangle"></i>
                <span id="reasonText">Your session has expired due to inactivity.</span>
            </div>
            
            <div class="buttons">
                <a href="login.php" class="btn btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login Again
                </a>
                <a href="index.php" class="btn btn-home">
                    <i class="fas fa-home"></i> Go to Homepage
                </a>
            </div>
        </div>
        
        <div class="security-info">
            <p><i class="fas fa-shield-alt"></i> All session data has been securely cleared. For your safety, please close the browser if you're on a shared device.</p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get URL parameters to check logout reason
            const urlParams = new URLSearchParams(window.location.search);
            const reason = urlParams.get('reason');
            const reasonBox = document.getElementById('reasonBox');
            const reasonText = document.getElementById('reasonText');
            const logoutTitle = document.getElementById('logoutTitle');
            const lockIcon = document.getElementById('lockIcon');
            const animationContainer = document.getElementById('animationContainer');
            
            // Handle different logout reasons
            if (reason) {
                reasonBox.classList.add('active');
                
                if (reason === 'timeout') {
                    reasonText.textContent = 'Your session has expired due to inactivity.';
                    logoutTitle.textContent = 'Session Expired';
                } else if (reason === 'multi-login') {
                    reasonText.textContent = 'You have been logged out from this device because you logged in from another device.';
                    logoutTitle.textContent = 'Security Logout';
                } else if (reason === 'security') {
                    reasonText.textContent = 'You have been logged out for security reasons.';
                    logoutTitle.textContent = 'Security Logout';
                }
            }
            
            // Animation timeline
            const tl = gsap.timeline();
            
            // Initial animation
            tl.from('.container', { 
                duration: 0.8, 
                opacity: 0, 
                y: 30, 
                ease: "power2.out" 
            })
            .from('.logo', { 
                duration: 0.6, 
                opacity: 0, 
                y: -20, 
                ease: "back.out(1.7)" 
            }, "-=0.4")
            .from('.icon-container', { 
                duration: 0.8, 
                scale: 0, 
                rotation: 360, 
                ease: "back.out(1.7)" 
            })
            .from('.message', { 
                duration: 0.6, 
                opacity: 0, 
                y: 20, 
                ease: "power2.out" 
            })
            .from('.buttons .btn', { 
                duration: 0.5, 
                opacity: 0, 
                y: 20, 
                stagger: 0.1, 
                ease: "power2.out" 
            });
            
            // Lock animation
            tl.to(lockIcon, {
                duration: 0.5,
                scale: 1.2,
                ease: "power2.inOut",
                repeat: 1,
                yoyo: true
            });
            
            // Create floating bank cards animation
            function createFloatingCards() {
                for (let i = 0; i < 5; i++) {
                    const card = document.createElement('div');
                    card.classList.add('floating-card');
                    
                    // Random position
                    const leftPos = Math.random() * 100;
                    card.style.left = `${leftPos}%`;
                    card.style.top = `${Math.random() * 100}%`;
                    
                    animationContainer.appendChild(card);
                    
                    // Animate the card
                    gsap.to(card, {
                        duration: 2 + Math.random() * 3,
                        y: -1000,
                        rotation: Math.random() * 360,
                        opacity: 0.7,
                        delay: Math.random() * 2,
                        ease: "power1.in",
                        onComplete: function() {
                            card.remove();
                        }
                    });
                }
            }
            
            // Start card animation after a delay
            setTimeout(createFloatingCards, 1000);
            setInterval(createFloatingCards, 3000);
            
            // Add floating animation to the lock icon
            gsap.to(lockIcon, {
                duration: 3,
                y: -10,
                repeat: -1,
                yoyo: true,
                ease: "sine.inOut"
            });
            
            // Simulate PHP session destruction (for demo purposes)
            console.log("Session destroyed. All user data cleared.");
            
            // Clear any stored credentials (in a real app, this would clear cookies)
            document.cookie.split(";").forEach(function(c) {
                document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
            });
            
            // Clear localStorage and sessionStorage (if used)
            localStorage.clear();
            sessionStorage.clear();
        });
    </script>
</body>
</html>